# Torath (تراث) — Frontend

Digital Egyptian Heritage Library. React 19 + TypeScript + Vite frontend consuming the Torath ASP.NET Core Web API.

## Status: full CRUD complete, all four backend fixes confirmed

All backend fixes verified against the live repo, including the `databaseId` search fix pushed after the initial half-fix was flagged — confirmed present in `ElasticSearchService.SearchAsync`'s results projection now.

## What's real and functional

- **Public site:** Home (hero, news ticker, live Latest-content carousels, Featured Categories, closing CTA — all against real data), Browse (5 tabs: Books/Magazines/Newspapers/Articles/Research Papers, each with its own entity-specific filters), Search (unified, highlighted, routes correctly via the new `databaseId`), and full detail pages for all 7 content types
- **Auth:** Login/Register wired to the real endpoints; the entire app (per your explicit instruction) sits behind the login wall except Login/Register/404
- **Admin — full CRUD for every entity:** Books, Magazines, Newspapers, Articles, Research Papers, Categories — each with create/edit (modal form, Zod validation), delete (confirm dialog), and image/PDF upload where the entity supports it. Admin Dashboard shows live entity counts (derived client-side — no stats endpoint exists) and quick links. Search Index rebuild triggers all six endpoints for real.
- **Visual system:** all 9 supplied photos placed with legibility-tuned overlays (hero, Featured Categories, closing CTA, Auth pages, Browse header), optimized from 6.4MB down to ~1.2MB total; `ContentCard` + `Carousel` used consistently across Home/Browse; Framer Motion throughout (page transitions, stagger grids, card hover lift, reduced-motion-aware everywhere including the news ticker)

## Known gaps / honest scope notes

- **Magazine/Newspaper Issue management has no dedicated admin UI.** Articles reference issues by raw numeric ID in the admin form (no issue-picker dropdown) — functional but not polished; a proper picker needs an issues-by-parent endpoint wired into a two-step select.
- **No dashboard stats endpoint** — counts on the Admin Dashboard cost 5 extra list requests (pageSize=1) on load. Fine at current scale; swap for a real endpoint if one gets built.
- **Main JS bundle is ~558KB** (179KB gzipped) since Home loads eagerly with all its dependencies (Framer Motion, React Query, Radix). Every other route is already lazy-split; splitting vendor chunks further is a quick follow-up, not done here.

## Getting started

```bash
npm install
cp .env.example .env   # point VITE_API_BASE_URL at your running backend
npm run dev
```

## Project structure

Feature-sliced under `src/features/<domain>/{api,hooks,components,pages,types.ts}`. See the Phase 1 architecture document for the full rationale and folder map.

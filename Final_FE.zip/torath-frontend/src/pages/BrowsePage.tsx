import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { ContentCard } from "@/components/shared/ContentCard";
import { ContentCardGridSkeleton } from "@/components/shared/Skeletons";
import { EmptyState } from "@/components/shared/EmptyState";
import { ErrorState } from "@/components/shared/ErrorState";
import { Pagination } from "@/components/shared/Pagination";
import { BackgroundSection } from "@/components/shared/BackgroundSection";
import { SortControl, applySort, type SortOption } from "@/components/shared/RatingBadge";
import { StaggerGrid } from "@/components/motion/StaggerGrid";
import { useBooks } from "@/features/books/hooks/useBooks";
import { useMagazines } from "@/features/magazines/hooks/useMagazines";
import { useNewspapers } from "@/features/newspapers/hooks/useNewspapers";
import { useArticles } from "@/features/articles/hooks/useArticles";
import { useResearchPapers } from "@/features/research-papers/hooks/useResearchPapers";
import { useCategories } from "@/features/categories/hooks/useCategories";
import sphinxNileSunset from "@/assets/backgrounds/sphinx-nile-sunset.jpg";

const TABS = [
  { key: "books", label: "Books" },
  { key: "magazines", label: "Magazines" },
  { key: "newspapers", label: "Newspapers" },
  { key: "articles", label: "Articles" },
  { key: "research-papers", label: "Research Papers" },
];

const PAGE_SIZE = 12;

export function BrowsePage() {
  const [params, setParams] = useSearchParams();
  const activeType = params.get("type") ?? "books";
  const page = Number(params.get("page") ?? 1);

  const setTab = (key: string) => setParams({ type: key, page: "1" });
  const setPage = (p: number) =>
    setParams({ type: activeType, page: String(p) });

  return (
    <div>
      <BackgroundSection image={sphinxNileSunset} overlay="dark" intensity="medium">
        <div className="mx-auto max-w-7xl px-4 py-14">
          <h1 className="font-display text-4xl">Browse the collection</h1>
          <p className="mt-1 text-sm text-white/80">
            Each tab reads its own filters directly from the backend — Books
            by category/language, Research Papers by year.
          </p>
        </div>
      </BackgroundSection>

      <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="flex gap-2 overflow-x-auto border-b border-border">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setTab(tab.key)}
            className={`whitespace-nowrap border-b-2 px-4 py-2 text-sm transition-colors ${
              activeType === tab.key
                ? "border-accent font-medium text-accent"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mt-8">
        {activeType === "books" && <BooksTab page={page} onPageChange={setPage} />}
        {activeType === "magazines" && (
          <MagazinesTab page={page} onPageChange={setPage} />
        )}
        {activeType === "newspapers" && (
          <NewspapersTab page={page} onPageChange={setPage} />
        )}
        {activeType === "articles" && (
          <ArticlesTab page={page} onPageChange={setPage} />
        )}
        {activeType === "research-papers" && (
          <ResearchPapersTab page={page} onPageChange={setPage} />
        )}
      </div>
      </div>
    </div>
  );
}

type TabProps = { page: number; onPageChange: (page: number) => void };

function BooksTab({ page, onPageChange }: TabProps) {
  const [category, setCategory] = useState("");
  const [language, setLanguage] = useState("");
  const [sort, setSort] = useState<SortOption>("default");
  const { data: categories } = useCategories({ pageSize: 100 });
  const { data, isLoading, isError, refetch } = useBooks({
    page,
    pageSize: PAGE_SIZE,
    category: category || undefined,
    language: language || undefined,
  });
  const rows = applySort(data?.data ?? [], sort);

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-3">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded border border-border bg-surface px-3 py-1.5 text-sm"
          >
            <option value="">All categories</option>
            {categories?.data.map((c) => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="rounded border border-border bg-surface px-3 py-1.5 text-sm"
          >
            <option value="">All languages</option>
            <option value="English">English</option>
            <option value="Arabic">Arabic</option>
          </select>
        </div>
        <SortControl value={sort} onChange={setSort} />
      </div>

      {isLoading && <ContentCardGridSkeleton />}
      {isError && <ErrorState onRetry={() => refetch()} />}
      {data && data.data.length === 0 && (
        <EmptyState
          title="No books match these filters"
          description="Try widening your search."
        />
      )}
      {data && data.data.length > 0 && (
        <>
          <StaggerGrid className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
            {rows.map((book) => (
              <ContentCard
                key={book.id}
                href={`/books/${book.id}`}
                title={book.title}
                subtitle={book.authors}
                contentType="Book"
                id={book.id}
                coverUrl={book.coverImageUrl}
              />
            ))}
          </StaggerGrid>
          <Pagination
            page={data.pageNumber}
            pageSize={data.pageSize}
            totalCount={data.totalRecords}
            onPageChange={onPageChange}
          />
        </>
      )}
    </div>
  );
}

function MagazinesTab({ page, onPageChange }: TabProps) {
  const [sort, setSort] = useState<SortOption>("default");
  const { data, isLoading, isError, refetch } = useMagazines({
    page,
    pageSize: PAGE_SIZE,
  });
  const rows = applySort(data?.data ?? [], sort);

  if (isLoading) return <ContentCardGridSkeleton />;
  if (isError) return <ErrorState onRetry={() => refetch()} />;
  if (!data || data.data.length === 0)
    return <EmptyState title="No magazines yet" />;

  return (
    <>
      <div className="mb-6 flex justify-end">
        <SortControl value={sort} onChange={setSort} />
      </div>
      <StaggerGrid className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
        {rows.map((mag) => (
          <ContentCard
            key={mag.id}
            href={`/magazines/${mag.id}`}
            title={mag.title ?? "Untitled"}
            subtitle={mag.publisher}
            contentType="Magazine"
            id={mag.id}
            coverUrl={mag.coverImageUrl}
            ratio="wide"
          />
        ))}
      </StaggerGrid>
      <Pagination
        page={data.pageNumber}
        pageSize={data.pageSize}
        totalCount={data.totalRecords}
        onPageChange={onPageChange}
      />
    </>
  );
}

function NewspapersTab({ page, onPageChange }: TabProps) {
  const [sort, setSort] = useState<SortOption>("default");
  const { data, isLoading, isError, refetch } = useNewspapers({
    page,
    pageSize: PAGE_SIZE,
  });
  const rows = applySort(data?.data ?? [], sort);

  if (isLoading) return <ContentCardGridSkeleton />;
  if (isError) return <ErrorState onRetry={() => refetch()} />;
  if (!data || data.data.length === 0)
    return <EmptyState title="No newspapers yet" />;

  return (
    <>
      <div className="mb-6 flex justify-end">
        <SortControl value={sort} onChange={setSort} />
      </div>
      <StaggerGrid className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
        {rows.map((np) => (
          <ContentCard
            key={np.id}
            href={`/newspapers/${np.id}`}
            title={np.title ?? "Untitled"}
            subtitle={np.publisher}
            contentType="Newspaper"
            id={np.id}
            coverUrl={np.coverImageUrl}
            ratio="wide"
          />
        ))}
      </StaggerGrid>
      <Pagination
        page={data.pageNumber}
        pageSize={data.pageSize}
        totalCount={data.totalRecords}
        onPageChange={onPageChange}
      />
    </>
  );
}

function ArticlesTab({ page, onPageChange }: TabProps) {
  const [sort, setSort] = useState<SortOption>("default");
  const { data, isLoading, isError, refetch } = useArticles({
    page,
    pageSize: PAGE_SIZE,
  });
  const rows = applySort(data?.data ?? [], sort);

  if (isLoading) return <ContentCardGridSkeleton />;
  if (isError) return <ErrorState onRetry={() => refetch()} />;
  if (!data || data.data.length === 0)
    return <EmptyState title="No articles yet" />;

  return (
    <>
      <div className="mb-6 flex justify-end">
        <SortControl value={sort} onChange={setSort} />
      </div>
      <StaggerGrid className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
        {rows.map((article) => (
          <ContentCard
            key={article.id}
            href={`/articles/${article.id}`}
            title={article.title ?? "Untitled"}
            subtitle={article.author}
            contentType="Article"
            id={article.id}
            coverUrl={article.coverImageUrl}
          />
        ))}
      </StaggerGrid>
      <Pagination
        page={data.pageNumber}
        pageSize={data.pageSize}
        totalCount={data.totalRecords}
        onPageChange={onPageChange}
      />
    </>
  );
}

function ResearchPapersTab({ page, onPageChange }: TabProps) {
  const [year, setYear] = useState("");
  const [sort, setSort] = useState<SortOption>("default");
  const { data, isLoading, isError, refetch } = useResearchPapers({
    page,
    pageSize: PAGE_SIZE,
    publicationYear: year ? Number(year) : undefined,
  });
  const rows = applySort(data?.data ?? [], sort);

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <input
          type="number"
          placeholder="Filter by year…"
          value={year}
          onChange={(e) => setYear(e.target.value)}
          className="w-40 rounded border border-border bg-surface px-3 py-1.5 text-sm"
        />
        <SortControl value={sort} onChange={setSort} />
      </div>

      {isLoading && <ContentCardGridSkeleton />}
      {isError && <ErrorState onRetry={() => refetch()} />}
      {data && data.data.length === 0 && (
        <EmptyState title="No research papers match this year" />
      )}
      {data && data.data.length > 0 && (
        <>
          <StaggerGrid className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
            {rows.map((paper) => (
              <ContentCard
                key={paper.id}
                href={`/research-papers/${paper.id}`}
                title={paper.title}
                subtitle={paper.author}
                contentType="ResearchPaper"
                id={paper.id}
                coverUrl={paper.coverImageUrl}
              />
            ))}
          </StaggerGrid>
          <Pagination
            page={data.pageNumber}
            pageSize={data.pageSize}
            totalCount={data.totalRecords}
            onPageChange={onPageChange}
          />
        </>
      )}
    </div>
  );
}

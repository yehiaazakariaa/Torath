import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Search as SearchIcon, ChevronRight } from "lucide-react";
import { useSearch } from "@/features/search/hooks/useSearch";
import { resolveResultId, type SearchResult } from "@/features/search/types";
import { EmptyState } from "@/components/shared/EmptyState";
import { ErrorState } from "@/components/shared/ErrorState";
import { ContentCardGridSkeleton } from "@/components/shared/Skeletons";
import { Pagination } from "@/components/shared/Pagination";

/** Maps the Elasticsearch ContentType string to a detail route. Returns null if unroutable. */
function resultHref(result: SearchResult): string | null {
  const id = resolveResultId(result);
  if (id === null) return null;

  switch (result.contentType) {
    case "Book":
      return `/books/${id}`;
    case "Magazine":
      return `/magazines/${id}`;
    case "Newspaper":
      return `/newspapers/${id}`;
    case "Article":
      return `/articles/${id}`;
    case "Research Paper":
      return `/research-papers/${id}`;
    default:
      return null;
  }
}

function Highlighted({ html }: { html: string }) {
  // Elasticsearch highlight fragments already contain <mark> tags applied
  // server-side from our own indexed content — not raw user input.
  return <span dangerouslySetInnerHTML={{ __html: html }} />;
}

export function SearchPage() {
  const [urlParams, setUrlParams] = useSearchParams();
  const [queryInput, setQueryInput] = useState(urlParams.get("q") ?? "");
  const page = Number(urlParams.get("page") ?? 1);

  const { data, isLoading, isError, error, refetch } = useSearch({
    query: urlParams.get("q") ?? undefined,
    pageNumber: page,
    pageSize: 10,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUrlParams({ q: queryInput, page: "1" });
  };

  const activeQuery = urlParams.get("q");

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="font-display text-3xl">Search Torath</h1>

      <form onSubmit={handleSubmit} className="mt-6 flex gap-2">
        <div className="relative flex-1">
          <SearchIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={queryInput}
            onChange={(e) => setQueryInput(e.target.value)}
            placeholder="Search books, magazines, newspapers, articles, research papers…"
            className="w-full rounded border border-border bg-surface py-2 pl-10 pr-3 text-sm"
          />
        </div>
        <button
          type="submit"
          className="rounded bg-accent px-4 py-2 text-sm font-medium text-accent-foreground"
        >
          Search
        </button>
      </form>

      <div className="mt-8">
        {!activeQuery && (
          <EmptyState
            title="Start typing to search"
            description="Search spans every content type in the archive at once."
          />
        )}

        {activeQuery && isLoading && <ContentCardGridSkeleton count={4} />}

        {activeQuery && isError && (
          <ErrorState
            message={error && "message" in error ? String(error.message) : undefined}
            onRetry={() => refetch()}
          />
        )}

        {activeQuery && data && data.results.length === 0 && (
          <EmptyState
            title="No matches"
            description="Try a different keyword, or check the spelling."
          />
        )}

        {activeQuery && data && data.results.length > 0 && (
          <>
            <p className="mb-4 text-sm text-muted-foreground">
              {data.totalResults} result{data.totalResults === 1 ? "" : "s"}
            </p>
            <ul className="divide-y divide-border">
              {data.results.map((result) => {
                const href = resultHref(result);
                const titleHighlight = result.highlights?.title?.[0];
                const descHighlight = result.highlights?.description?.[0];

                const content = (
                  <div className="flex items-center justify-between gap-4 py-4">
                    <div className="min-w-0">
                      <span className="inline-flex items-center rounded-sm bg-info/10 px-2 py-0.5 text-xs font-medium text-info">
                        {result.contentType}
                      </span>
                      <h3 className="mt-2 font-display text-lg">
                        {titleHighlight ? (
                          <Highlighted html={titleHighlight} />
                        ) : (
                          result.title
                        )}
                      </h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {descHighlight ? (
                          <Highlighted html={descHighlight} />
                        ) : (
                          result.description
                        )}
                      </p>
                    </div>
                    {href && (
                      <ChevronRight className="h-4 w-4 flex-shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
                    )}
                  </div>
                );

                return (
                  <li key={result.id}>
                    {href ? (
                      <Link to={href} className="group block cursor-pointer hover:bg-muted/50">
                        {content}
                      </Link>
                    ) : (
                      content
                    )}
                  </li>
                );
              })}
            </ul>

            <Pagination
              page={data.pageNumber}
              pageSize={data.pageSize}
              totalCount={data.totalResults}
              onPageChange={(p) =>
                setUrlParams({ q: activeQuery ?? "", page: String(p) })
              }
            />
          </>
        )}
      </div>
    </div>
  );
}

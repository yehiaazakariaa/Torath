import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { FadeIn } from "@/components/motion/FadeIn";
import { BackgroundSection } from "@/components/shared/BackgroundSection";
import { NewsTicker } from "@/components/shared/NewsTicker";
import { Carousel } from "@/components/shared/Carousel";
import { ContentCard } from "@/components/shared/ContentCard";
import { ContentCardGridSkeleton } from "@/components/shared/Skeletons";
import { useBooks } from "@/features/books/hooks/useBooks";
import { useMagazines } from "@/features/magazines/hooks/useMagazines";
import { useNewspapers } from "@/features/newspapers/hooks/useNewspapers";
import { useArticles } from "@/features/articles/hooks/useArticles";
import { useResearchPapers } from "@/features/research-papers/hooks/useResearchPapers";
import { useCategories } from "@/features/categories/hooks/useCategories";
import { useAuthStore } from "@/features/auth/store";

import pharaohHero from "@/assets/backgrounds/pharaoh-mask-hero.jpg";
import hieroglyphPattern from "@/assets/backgrounds/hieroglyph-gold-pattern.jpg";
import fantasyLibrary from "@/assets/backgrounds/fantasy-library.jpg";

export function HomePage() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const books = useBooks({ page: 1, pageSize: 8 });
  const magazines = useMagazines({ page: 1, pageSize: 8 });
  const newspapers = useNewspapers({ page: 1, pageSize: 8 });
  const papers = useResearchPapers({ page: 1, pageSize: 8 });
  const articles = useArticles({ page: 1, pageSize: 8 });
  const categories = useCategories({ pageSize: 8 });

  const tickerItems = [
    ...(books.data?.data.slice(0, 3).map((b) => `New book: ${b.title}`) ?? []),
    ...(papers.data?.data
      .slice(0, 3)
      .map((p) => `New research paper: ${p.title}`) ?? []),
    ...(newspapers.data?.data
      .slice(0, 2)
      .map((n) => `Newspaper added: ${n.title}`) ?? []),
    ...(articles.data?.data
      .slice(0, 2)
      .map((a) => `New article: ${a.title}`) ?? []),
  ];

  return (
    <div>
      {/* Hero — dark overlay over the pharaoh mask photo, gold accent already matches the mask's own palette */}
      <BackgroundSection
        image={pharaohHero}
        overlay="dark"
        intensity="medium"
        priority
      >
        <div className="mx-auto max-w-7xl px-4 py-28 md:py-40">
          <FadeIn>
            <p className="text-xs uppercase tracking-widest text-accent">
              Digital Egyptian Heritage Library
            </p>
            <h1 className="mt-4 max-w-2xl font-display text-5xl leading-tight md:text-6xl">
              Every book, every issue, catalogued.
            </h1>
            <p className="mt-6 max-w-xl text-white/85">
              Torath preserves Egypt's books, magazines, newspapers, and
              research in one searchable archive — open, cited, and built to
              last.
            </p>
            <div className="mt-8 flex gap-3">
              <Button size="lg" asChild>
                <Link to="/search">Search the archive</Link>
              </Button>
              <Button size="lg" variant="secondary" asChild>
                <Link to="/browse">Browse collections</Link>
              </Button>
            </div>
          </FadeIn>
        </div>
      </BackgroundSection>

      <NewsTicker items={tickerItems} />

      <Section title="Latest Books" viewAllHref="/browse?type=books">
        {books.isLoading ? (
          <ContentCardGridSkeleton count={4} />
        ) : (
          <Carousel>
            {(books.data?.data ?? []).map((book) => (
              <ContentCard
                key={book.id}
                href={`/books/${book.id}`}
                title={book.title}
                subtitle={book.authors}
                contentType="Book"
                id={book.id}
                coverUrl={book.coverImageUrl}
              />
            ))}
          </Carousel>
        )}
      </Section>

      <Section title="Latest Magazines" viewAllHref="/browse?type=magazines">
        {magazines.isLoading ? (
          <ContentCardGridSkeleton count={4} />
        ) : (
          <Carousel>
            {(magazines.data?.data ?? []).map((mag) => (
              <ContentCard
                key={mag.id}
                href={`/magazines/${mag.id}`}
                title={mag.title ?? "Untitled"}
                subtitle={mag.publisher}
                contentType="Magazine"
                id={mag.id}
                coverUrl={mag.coverImageUrl}
                ratio="wide"
              />
            ))}
          </Carousel>
        )}
      </Section>

      <Section title="Latest Newspapers" viewAllHref="/browse?type=newspapers">
        {newspapers.isLoading ? (
          <ContentCardGridSkeleton count={4} />
        ) : (
          <Carousel>
            {(newspapers.data?.data ?? []).map((np) => (
              <ContentCard
                key={np.id}
                href={`/newspapers/${np.id}`}
                title={np.title ?? "Untitled"}
                subtitle={np.publisher}
                contentType="Newspaper"
                id={np.id}
                coverUrl={np.coverImageUrl}
                ratio="wide"
              />
            ))}
          </Carousel>
        )}
      </Section>

      <Section title="Latest Articles" viewAllHref="/browse?type=articles">
        {articles.isLoading ? (
          <ContentCardGridSkeleton count={4} />
        ) : (
          <Carousel>
            {(articles.data?.data ?? []).map((article) => (
              <ContentCard
                key={article.id}
                href={`/articles/${article.id}`}
                title={article.title ?? "Untitled"}
                subtitle={article.author}
                contentType="Article"
                id={article.id}
                coverUrl={article.coverImageUrl}
              />
            ))}
          </Carousel>
        )}
      </Section>

      <Section
        title="Latest Research Papers"
        viewAllHref="/browse?type=research-papers"
      >
        {papers.isLoading ? (
          <ContentCardGridSkeleton count={4} />
        ) : (
          <Carousel>
            {(papers.data?.data ?? []).map((paper) => (
              <ContentCard
                key={paper.id}
                href={`/research-papers/${paper.id}`}
                title={paper.title}
                subtitle={paper.author}
                contentType="ResearchPaper"
                id={paper.id}
                coverUrl={paper.coverImageUrl}
              />
            ))}
          </Carousel>
        )}
      </Section>

      {/* Featured Categories — gold hieroglyph pattern on black, dark overlay so the gold linework stays visible but doesn't compete with the card grid */}
      <BackgroundSection image={hieroglyphPattern} overlay="dark" intensity="strong">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <FadeIn>
            <h2 className="font-display text-3xl">Featured Categories</h2>
          </FadeIn>
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {(categories.data?.data ?? []).map((cat, i) => (
              <FadeIn key={cat.id} delay={i * 0.05}>
                <Link
                  to={`/browse?type=books&category=${encodeURIComponent(cat.name)}`}
                  className="block rounded border border-white/20 bg-white/5 px-5 py-6 backdrop-blur-sm transition-colors hover:bg-white/10"
                >
                  <p className="font-display text-lg">{cat.name}</p>
                  {cat.description && (
                    <p className="mt-1 line-clamp-2 text-xs text-white/70">
                      {cat.description}
                    </p>
                  )}
                </Link>
              </FadeIn>
            ))}
          </div>
        </div>
      </BackgroundSection>

      {/* Closing CTA — the fantasy library photo, dark overlay. Only
          prompts registration for guests; a signed-in user gets a
          browse-oriented close instead of a redundant sign-up prompt. */}
      <BackgroundSection image={fantasyLibrary} overlay="dark" intensity="strong">
        <div className="mx-auto max-w-3xl px-4 py-24 text-center">
          <FadeIn>
            <h2 className="font-display text-3xl">
              Every record has a story behind it.
            </h2>
            {isAuthenticated ? (
              <>
                <p className="mt-3 text-white/80">
                  Keep exploring the full archive.
                </p>
                <Button size="lg" className="mt-6" asChild>
                  <Link to="/browse">Browse the collection</Link>
                </Button>
              </>
            ) : (
              <>
                <p className="mt-3 text-white/80">
                  Register to search, read, and cite the full archive.
                </p>
                <Button size="lg" className="mt-6" asChild>
                  <Link to="/register">Create an account</Link>
                </Button>
              </>
            )}
          </FadeIn>
        </div>
      </BackgroundSection>
    </div>
  );
}

function Section({
  title,
  viewAllHref,
  children,
}: {
  title: string;
  viewAllHref: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-12">
      <FadeIn>
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-display text-2xl">{title}</h2>
          <Link to={viewAllHref} className="text-sm text-info hover:underline">
            View all
          </Link>
        </div>
        {children}
      </FadeIn>
    </section>
  );
}

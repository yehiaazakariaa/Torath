import { useEffect } from "react";
import { Toaster } from "sonner";
import { QueryProvider } from "./providers/QueryProvider";
import { ThemeProvider } from "./providers/ThemeProvider";
import { AppRouter } from "./router";
import { useAuthStore } from "@/features/auth/store";

export function App() {
  const hydrate = useAuthStore((s) => s.hydrate);

  // Restore session from localStorage on boot — there's no /auth/me
  // endpoint, so this is purely a client-side JWT decode (see Phase 1 §9a).
  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <QueryProvider>
      <ThemeProvider>
        <AppRouter />
        <Toaster position="bottom-right" richColors />
      </ThemeProvider>
    </QueryProvider>
  );
}

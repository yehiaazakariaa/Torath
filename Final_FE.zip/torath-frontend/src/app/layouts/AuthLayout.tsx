import { Link, Outlet } from "react-router-dom";
import { BackgroundSection } from "@/components/shared/BackgroundSection";
import candlelitLibrary from "@/assets/backgrounds/candlelit-library.jpg";

export function AuthLayout() {
  return (
    <BackgroundSection
      image={candlelitLibrary}
      overlay="dark"
      intensity="strong"
      className="flex min-h-screen items-center justify-center px-4"
    >
      <div className="w-full max-w-sm">
        <Link
          to="/"
          className="mb-8 block text-center font-display text-2xl text-white"
        >
          Torath <span className="text-accent">تراث</span>
        </Link>
        <div className="rounded border border-white/10 bg-background p-8 text-foreground">
          <Outlet />
        </div>
      </div>
    </BackgroundSection>
  );
}

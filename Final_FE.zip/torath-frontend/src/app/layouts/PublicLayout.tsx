import { Link, Outlet } from "react-router-dom";
import { Moon, Search, Sun } from "lucide-react";
import { useTheme } from "@/app/providers/ThemeProvider";
import { useAuthStore } from "@/features/auth/store";
import { Button } from "@/components/ui/button";
import { PageTransition } from "@/components/motion/PageTransition";

const NAV_LINKS = [
  { to: "/browse?type=books", label: "Books" },
  { to: "/browse?type=magazines", label: "Magazines" },
  { to: "/browse?type=newspapers", label: "Newspapers" },
  { to: "/browse?type=articles", label: "Articles" },
  { to: "/browse?type=research-papers", label: "Research Papers" },
];

export function PublicLayout() {
  const { theme, toggleTheme } = useTheme();
  const { isAuthenticated, session, logout } = useAuthStore();

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
          <Link to="/" className="font-display text-xl">
            Torath <span className="text-accent">تراث</span>
          </Link>

          <nav className="hidden items-center gap-6 md:flex">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.label}
                to={link.to}
                className="text-sm text-foreground/80 transition-colors hover:text-foreground"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" asChild>
              <Link to="/search" aria-label="Search">
                <Search className="h-4 w-4" />
              </Link>
            </Button>
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === "light" ? (
                <Moon className="h-4 w-4" />
              ) : (
                <Sun className="h-4 w-4" />
              )}
            </Button>
            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                {session?.isAdmin && (
                  <Button variant="secondary" size="sm" asChild>
                    <Link to="/admin">Admin</Link>
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={logout}>
                  Sign out
                </Button>
              </div>
            ) : (
              <Button variant="secondary" size="sm" asChild>
                <Link to="/login">Sign in</Link>
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        <PageTransition>
          <Outlet />
        </PageTransition>
      </main>

      <footer className="border-t border-border bg-surface">
        <div className="mx-auto max-w-7xl px-4 py-12 text-sm text-muted-foreground">
          <p className="font-display text-lg text-foreground">Torath تراث</p>
          <p className="mt-2 max-w-md">
            A digital archive of Egyptian books, magazines, newspapers, and
            research, preserved for open access.
          </p>
          <p className="mt-8 border-t border-border pt-4 text-xs">
            This project was made by Yehia Zakaria Fawzi
          </p>
        </div>
      </footer>
    </div>
  );
}

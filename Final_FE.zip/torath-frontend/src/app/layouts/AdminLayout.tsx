import { Link, NavLink, Outlet } from "react-router-dom";
import { Home } from "lucide-react";
import { useAuthStore } from "@/features/auth/store";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils/cn";

const ADMIN_LINKS = [
  { to: "/admin", label: "Dashboard", end: true },
  { to: "/admin/books", label: "Books" },
  { to: "/admin/magazines", label: "Magazines" },
  { to: "/admin/newspapers", label: "Newspapers" },
  { to: "/admin/articles", label: "Articles" },
  { to: "/admin/research-papers", label: "Research Papers" },
  { to: "/admin/categories", label: "Categories" },
  { to: "/admin/search-index", label: "Search Index" },
];

export function AdminLayout() {
  const { logout } = useAuthStore();

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-64 flex-col border-r border-border bg-surface p-4 md:flex">
        <Link to="/" className="mb-2 font-display text-lg">
          Torath <span className="text-accent">Admin</span>
        </Link>
        <Button
          variant="ghost"
          size="sm"
          asChild
          className="mb-6 justify-start text-muted-foreground"
        >
          <Link to="/">
            <Home className="h-4 w-4" /> Back to Home
          </Link>
        </Button>
        <nav className="flex flex-1 flex-col gap-1">
          {ADMIN_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) =>
                cn(
                  "rounded px-3 py-2 text-sm transition-colors",
                  isActive
                    ? "bg-accent/10 text-accent font-medium"
                    : "text-foreground/70 hover:bg-muted"
                )
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <Button variant="ghost" size="sm" onClick={logout}>
          Sign out
        </Button>
      </aside>

      <main className="flex-1 p-6 md:p-10">
        <Outlet />
      </main>
    </div>
  );
}

import { lazy, Suspense } from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { PublicLayout } from "@/app/layouts/PublicLayout";
import { AdminLayout } from "@/app/layouts/AdminLayout";
import { AuthLayout } from "@/app/layouts/AuthLayout";
import { RequireAuth } from "./RequireAuth";
import { RequireRole } from "./RequireRole";
import { HomePage } from "@/pages/HomePage";
import { NotFoundPage } from "@/pages/NotFoundPage";

// Route-based code splitting — every page below its layout is a separate chunk.
const BrowsePage = lazy(() =>
  import("@/pages/BrowsePage").then((m) => ({ default: m.BrowsePage }))
);
const SearchPage = lazy(() =>
  import("@/pages/SearchPage").then((m) => ({ default: m.SearchPage }))
);
const LoginPage = lazy(() =>
  import("@/features/auth/pages/LoginPage").then((m) => ({
    default: m.LoginPage,
  }))
);
const RegisterPage = lazy(() =>
  import("@/features/auth/pages/RegisterPage").then((m) => ({
    default: m.RegisterPage,
  }))
);
const BookDetailsPage = lazy(() =>
  import("@/features/books/pages/BookDetailsPage").then((m) => ({
    default: m.BookDetailsPage,
  }))
);
const MagazineDetailsPage = lazy(() =>
  import("@/features/magazines/pages/MagazineDetailsPage").then((m) => ({
    default: m.MagazineDetailsPage,
  }))
);
const MagazineIssueDetailsPage = lazy(() =>
  import("@/features/magazines/pages/MagazineIssueDetailsPage").then((m) => ({
    default: m.MagazineIssueDetailsPage,
  }))
);
const NewspaperDetailsPage = lazy(() =>
  import("@/features/newspapers/pages/NewspaperDetailsPage").then((m) => ({
    default: m.NewspaperDetailsPage,
  }))
);
const NewspaperIssueDetailsPage = lazy(() =>
  import("@/features/newspapers/pages/NewspaperIssueDetailsPage").then(
    (m) => ({ default: m.NewspaperIssueDetailsPage })
  )
);
const ArticleDetailsPage = lazy(() =>
  import("@/features/articles/pages/ArticleDetailsPage").then((m) => ({
    default: m.ArticleDetailsPage,
  }))
);
const ResearchPaperDetailsPage = lazy(() =>
  import("@/features/research-papers/pages/ResearchPaperDetailsPage").then(
    (m) => ({ default: m.ResearchPaperDetailsPage })
  )
);
const AdminDashboardPage = lazy(() =>
  import("@/features/admin/pages/AdminDashboardPage").then((m) => ({
    default: m.AdminDashboardPage,
  }))
);
const AdminBooksPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminBooksPage").then((m) => ({
    default: m.AdminBooksPage,
  }))
);
const AdminMagazinesPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminMagazinesPage").then((m) => ({
    default: m.AdminMagazinesPage,
  }))
);
const AdminNewspapersPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminNewspapersPage").then((m) => ({
    default: m.AdminNewspapersPage,
  }))
);
const AdminArticlesPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminArticlesPage").then((m) => ({
    default: m.AdminArticlesPage,
  }))
);
const AdminResearchPapersPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminResearchPapersPage").then(
    (m) => ({ default: m.AdminResearchPapersPage })
  )
);
const AdminCategoriesPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminCategoriesPage").then((m) => ({
    default: m.AdminCategoriesPage,
  }))
);
const AdminMagazineIssuesPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminMagazineIssuesPage").then((m) => ({
    default: m.AdminMagazineIssuesPage,
  }))
);
const AdminNewspaperIssuesPage = lazy(() =>
  import("@/features/admin/pages/entities/AdminNewspaperIssuesPage").then((m) => ({
    default: m.AdminNewspaperIssuesPage,
  }))
);
const AdminAnalyticsPage = lazy(() =>
  import("@/features/admin/pages/AdminAnalyticsPage").then((m) => ({
    default: m.AdminAnalyticsPage,
  }))
);
const AdminSearchIndexPage = lazy(() =>
  import("@/features/admin/pages/AdminSearchIndexPage").then((m) => ({
    default: m.AdminSearchIndexPage,
  }))
);

function Fallback() {
  return <div className="py-24 text-center text-sm text-muted-foreground">Loading…</div>;
}

function withSuspense(element: React.ReactNode) {
  return <Suspense fallback={<Fallback />}>{element}</Suspense>;
}

const router = createBrowserRouter([
  {
    element: <RequireAuth />,
    children: [
      {
        element: <PublicLayout />,
        children: [
          { path: "/", element: <HomePage /> },
          { path: "/browse", element: withSuspense(<BrowsePage />) },
          { path: "/search", element: withSuspense(<SearchPage />) },
          { path: "/books/:id", element: withSuspense(<BookDetailsPage />) },
          {
            path: "/magazines/:id",
            element: withSuspense(<MagazineDetailsPage />),
          },
          {
            path: "/magazines/:magazineId/issues/:id",
            element: withSuspense(<MagazineIssueDetailsPage />),
          },
          {
            path: "/newspapers/:id",
            element: withSuspense(<NewspaperDetailsPage />),
          },
          {
            path: "/newspapers/:newspaperId/issues/:id",
            element: withSuspense(<NewspaperIssueDetailsPage />),
          },
          {
            path: "/articles/:id",
            element: withSuspense(<ArticleDetailsPage />),
          },
          {
            path: "/research-papers/:id",
            element: withSuspense(<ResearchPaperDetailsPage />),
          },
        ],
      },
      {
        element: <RequireRole role="Admin" />,
        children: [
          {
            element: <AdminLayout />,
            children: [
              { path: "/admin", element: withSuspense(<AdminDashboardPage />) },
              {
                path: "/admin/analytics",
                element: withSuspense(<AdminAnalyticsPage />),
              },
              {
                path: "/admin/books",
                element: withSuspense(<AdminBooksPage />),
              },
              {
                path: "/admin/magazines",
                element: withSuspense(<AdminMagazinesPage />),
              },
              {
                path: "/admin/magazines/:magazineId/issues",
                element: withSuspense(<AdminMagazineIssuesPage />),
              },
              {
                path: "/admin/newspapers",
                element: withSuspense(<AdminNewspapersPage />),
              },
              {
                path: "/admin/newspapers/:newspaperId/issues",
                element: withSuspense(<AdminNewspaperIssuesPage />),
              },
              {
                path: "/admin/articles",
                element: withSuspense(<AdminArticlesPage />),
              },
              {
                path: "/admin/research-papers",
                element: withSuspense(<AdminResearchPapersPage />),
              },
              {
                path: "/admin/categories",
                element: withSuspense(<AdminCategoriesPage />),
              },
              {
                path: "/admin/search-index",
                element: withSuspense(<AdminSearchIndexPage />),
              },
            ],
          },
        ],
      },
    ],
  },
  {
    element: <AuthLayout />,
    children: [
      { path: "/login", element: withSuspense(<LoginPage />) },
      { path: "/register", element: withSuspense(<RegisterPage />) },
    ],
  },
  { path: "*", element: <NotFoundPage /> },
]);

export function AppRouter() {
  return <RouterProvider router={router} />;
}

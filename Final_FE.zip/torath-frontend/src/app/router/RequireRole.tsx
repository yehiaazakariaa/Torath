import { Navigate, Outlet } from "react-router-dom";
import { useAuthStore } from "@/features/auth/store";

/**
 * UX-level gate only — the backend is the real authorization boundary.
 * If the role claim is missing or ambiguous, fails closed (treats as
 * non-admin) rather than guessing. See Phase 1 doc §3.
 */
export function RequireRole({ role }: { role: string }) {
  const session = useAuthStore((s) => s.session);
  const isHydrated = useAuthStore((s) => s.isHydrated);
  const hasRole = session?.role === role;

  // Same hydration race as RequireAuth — wait before deciding.
  if (!isHydrated) return null;

  if (!hasRole) {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
}

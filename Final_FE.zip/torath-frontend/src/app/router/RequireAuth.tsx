import { Navigate, Outlet } from "react-router-dom";
import { useAuthStore } from "@/features/auth/store";

export function RequireAuth() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isHydrated = useAuthStore((s) => s.isHydrated);

  // Don't decide anything until the store has read localStorage — on a
  // hard page load (e.g. returning from Stripe Checkout) this runs
  // before that happens, and redirecting on the un-hydrated default
  // would log out a user who actually still has a valid token.
  if (!isHydrated) return null;

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
}

export type ContentType =
  | "Book"
  | "Magazine"
  | "MagazineIssue"
  | "Newspaper"
  | "NewspaperIssue"
  | "Article"
  | "ResearchPaper";

/** Prefix used by the AccessionTag signature element. */
export const CONTENT_TYPE_PREFIX: Record<ContentType, string> = {
  Book: "BK",
  Magazine: "MG",
  MagazineIssue: "MI",
  Newspaper: "NP",
  NewspaperIssue: "NI",
  Article: "AR",
  ResearchPaper: "RP",
};

/**
 * Confirmed against a real GET /api/Books response (2026-08-05).
 * Items are nested under "data", not "items"; metadata uses
 * totalRecords/pageNumber, not totalCount/page. Applied as the shared
 * shape for every list endpoint — reasonable since this is a generic
 * pagination wrapper, not something that varies per entity.
 */
export type PaginatedResponse<T> = {
  data: T[];
  totalRecords: number;
  pageNumber: number;
  pageSize: number;
};

export type Category = {
  id: number;
  name: string;
  description?: string | null;
};

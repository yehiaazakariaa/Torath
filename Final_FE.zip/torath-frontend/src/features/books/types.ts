/**
 * Matches BookWriteDto exactly (confirmed against DTOs/AssetDtos.cs).
 * Used for both create (POST) and update (PUT) request bodies.
 */
export type BookWriteDto = {
  title: string; // required, 1–200 chars
  description?: string | null; // max 1000 chars
  language: string; // required, 1–50 chars
  publicationDate: string; // ISO date-time — full date on WRITE
  publisher?: string | null; // max 200 chars
  categoryId: number;
  isbn: string; // required, 1–20 chars
  authors: string; // required, 1–200 chars
  numberOfPages: number;
  edition?: string | null; // max 50 chars
  coverImageUrl?: string | null;
  pdfFileUrl?: string | null;
};

/**
 * Confirmed against BookDto + BookService's Select projection
 * (2026-08-07) — ISBN/Authors/NumberOfPages/Edition are back and fully
 * populated on both GetAll and GetById.
 *
 * Still true from the previous rewrite (unchanged, not a gap — just how
 * the backend is designed): READ only returns `publicationYear` (derived
 * server-side as `b.PublicationDate.Year`), not the full date, and there
 * is no createdDate/updatedDate. `categoryName` is flat, no nested
 * `category` object.
 */
export type Book = {
  id: number;
  title: string;
  description: string;
  language: string;
  publisher: string;
  publicationYear: number;
  categoryId: number;
  categoryName: string;
  isbn: string;
  authors: string;
  numberOfPages: number;
  edition: string;
  coverImageUrl: string | null;
  pdfFileUrl: string | null;
  rating: number;
  viewCount: number;
};

export type BooksListParams = {
  page?: number;
  pageSize?: number;
  category?: string;
  language?: string;
};

import type { BooksListParams } from "../types";

export const booksKeys = {
  all: ["books"] as const,
  lists: () => [...booksKeys.all, "list"] as const,
  list: (params: BooksListParams) => [...booksKeys.lists(), params] as const,
  details: () => [...booksKeys.all, "detail"] as const,
  detail: (id: number) => [...booksKeys.details(), id] as const,
};

import { apiClient } from "@/lib/api/client";
import type { PaginatedResponse } from "@/types/common";
import type { Book, BooksListParams, BookWriteDto } from "../types";

export const booksService = {
  getAll: async (
    params: BooksListParams
  ): Promise<PaginatedResponse<Book>> => {
    const { data } = await apiClient.get<PaginatedResponse<Book>>(
      "/api/Books",
      { params }
    );
    return data;
  },

  getById: async (id: number): Promise<Book> => {
    const { data } = await apiClient.get<Book>(`/api/Books/${id}`);
    return data;
  },

  create: async (dto: BookWriteDto): Promise<Book> => {
    const { data } = await apiClient.post<Book>("/api/Books", dto);
    return data;
  },

  update: async (id: number, dto: BookWriteDto): Promise<void> => {
    await apiClient.put(`/api/Books/${id}`, dto);
  },

  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/Books/${id}`);
  },

  /** Anonymous — fired on detail page load. */
  incrementView: async (id: number): Promise<void> => {
    await apiClient.post(`/api/Books/${id}/view`);
  },

  /** Requires a logged-in user. Body is a raw double, 0–5. */
  rate: async (id: number, rating: number): Promise<void> => {
    await apiClient.post(`/api/Books/${id}/rate`, rating);
  },
};

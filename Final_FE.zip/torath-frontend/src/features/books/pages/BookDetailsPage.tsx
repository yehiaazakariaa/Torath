import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { toast } from "sonner";
import { useBook, useIncrementBookView, useRateBook } from "../hooks/useBooks";
import { AccessionTag } from "@/components/shared/AccessionTag";
import { CoverImage } from "@/components/shared/CoverImage";
import { PdfViewerLink } from "@/components/shared/PdfViewerLink";
import { ContentTypeBadge } from "@/components/shared/ContentTypeBadge";
import { ErrorState } from "@/components/shared/ErrorState";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { RatingInput } from "@/components/shared/RatingInput";
import { Skeleton } from "@/components/shared/Skeletons";
import { FadeIn } from "@/components/motion/FadeIn";

/**
 * BookDto (confirmed against the live backend, 2026-08-07) returns
 * title, description, language, publisher, publicationYear, isbn,
 * authors, numberOfPages, edition, categoryName, cover/pdf, rating,
 * viewCount.
 */
export function BookDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const bookId = Number(id);
  const { data: book, isLoading, isError, error, refetch } = useBook(bookId);
  const incrementView = useIncrementBookView(bookId);
  const rateBook = useRateBook(bookId);

  useEffect(() => {
    if (Number.isFinite(bookId)) {
      incrementView.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookId]);

  if (isLoading) {
    return (
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-10 md:grid-cols-[300px_1fr]">
        <Skeleton className="aspect-[4/5] w-full" />
        <div className="space-y-3">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
    );
  }

  if (isError || !book) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <ErrorState message={error && "message" in error ? String(error.message) : undefined} onRetry={() => refetch()} />
      </div>
    );
  }

  return (
    <FadeIn>
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-10 px-4 py-10 md:grid-cols-[300px_1fr]">
        <div>
          <CoverImage src={book.coverImageUrl} alt={book.title} ratio="portrait" />
        </div>

        <div>
          <div className="flex items-center gap-2">
            <ContentTypeBadge contentType="Book" />
            <AccessionTag contentType="Book" id={book.id} />
          </div>

          <h1 className="mt-3 font-display text-4xl">{book.title}</h1>
          <p className="mt-1 text-muted-foreground">{book.authors}</p>
          {book.categoryName && (
            <p className="mt-1 text-xs uppercase tracking-wide text-accent">
              {book.categoryName}
            </p>
          )}
          <RatingBadge rating={book.rating} viewCount={book.viewCount} className="mt-3" />
          <div className="mt-2">
            <RatingInput
              isSubmitting={rateBook.isPending}
              onRate={(rating) =>
                rateBook.mutate(rating, {
                  onSuccess: () => toast.success("Thanks for rating!"),
                  onError: () => toast.error("Couldn't submit your rating"),
                })
              }
            />
          </div>

          {book.description && (
            <p className="mt-6 max-w-2xl text-sm leading-relaxed">
              {book.description}
            </p>
          )}

          <dl className="mt-8 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3">
            <MetaField label="ISBN" value={book.isbn} />
            <MetaField label="Language" value={book.language} />
            <MetaField label="Publisher" value={book.publisher} />
            <MetaField label="Edition" value={book.edition} />
            <MetaField label="Pages" value={book.numberOfPages} />
            <MetaField label="Published" value={book.publicationYear} />
          </dl>

          <div className="mt-8">
            <PdfViewerLink url={book.pdfFileUrl} />
          </div>
        </div>
      </div>
    </FadeIn>
  );
}

function MetaField({
  label,
  value,
}: {
  label: string;
  value?: string | number | null;
}) {
  if (!value) return null;
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-0.5">{value}</dd>
    </div>
  );
}

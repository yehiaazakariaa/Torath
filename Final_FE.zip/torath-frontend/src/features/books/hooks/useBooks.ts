import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { booksService } from "../api/booksService";
import { booksKeys } from "../api/booksKeys";
import type { Book, BooksListParams, BookWriteDto } from "../types";
import type { PaginatedResponse } from "@/types/common";

export function useBooks(params: BooksListParams) {
  return useQuery({
    queryKey: booksKeys.list(params),
    queryFn: () => booksService.getAll(params),
    staleTime: 60_000,
  });
}

export function useBook(id: number) {
  return useQuery({
    queryKey: booksKeys.detail(id),
    queryFn: () => booksService.getById(id),
    enabled: Number.isFinite(id),
  });
}

/** Fire-and-forget — called once on detail page mount, not on card click
 * (a card click navigates to this page, so firing on both would double
 * count the same visit). Errors are swallowed; a failed view ping
 * shouldn't disrupt the page. */
export function useIncrementBookView(id: number) {
  return useMutation({
    mutationFn: () => booksService.incrementView(id),
  });
}

export function useRateBook(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (rating: number) => booksService.rate(id, rating),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: booksKeys.detail(id) });
      queryClient.invalidateQueries({ queryKey: booksKeys.lists() });
    },
  });
}

export function useCreateBook() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: BookWriteDto) => booksService.create(dto),
    onSuccess: (created) => {
      // Prepend into every cached list immediately — guarantees the new
      // row is visible on whatever page the admin is looking at, rather
      // than depending on backend sort order putting it on page 1.
      queryClient.setQueriesData<PaginatedResponse<Book>>(
        { queryKey: booksKeys.lists() },
        (old) =>
          old
            ? { ...old, data: [created, ...old.data], totalRecords: old.totalRecords + 1 }
            : old
      );
      queryClient.invalidateQueries({ queryKey: booksKeys.lists() });
    },
  });
}

export function useUpdateBook(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: BookWriteDto) => booksService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: booksKeys.lists() });
      queryClient.invalidateQueries({ queryKey: booksKeys.detail(id) });
    },
  });
}

export function useDeleteBook() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => booksService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<PaginatedResponse<Book>>(
        { queryKey: booksKeys.lists() },
        (old) =>
          old
            ? {
                ...old,
                data: old.data.filter((b) => b.id !== id),
                totalRecords: Math.max(0, old.totalRecords - 1),
              }
            : old
      );
      queryClient.invalidateQueries({ queryKey: booksKeys.lists() });
    },
  });
}

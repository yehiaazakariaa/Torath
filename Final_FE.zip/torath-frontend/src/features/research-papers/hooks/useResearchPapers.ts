import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { researchPapersService } from "../api/researchPapersService";
import type {
  ResearchPaper,
  ResearchPapersListParams,
  ResearchPaperWriteDto,
} from "../types";
import type { PaginatedResponse } from "@/types/common";

export const researchPapersKeys = {
  all: ["research-papers"] as const,
  lists: () => [...researchPapersKeys.all, "list"] as const,
  list: (params: ResearchPapersListParams) =>
    [...researchPapersKeys.lists(), params] as const,
  details: () => [...researchPapersKeys.all, "detail"] as const,
  detail: (id: number) => [...researchPapersKeys.details(), id] as const,
};

export function useResearchPapers(params: ResearchPapersListParams) {
  return useQuery({
    queryKey: researchPapersKeys.list(params),
    queryFn: () => researchPapersService.getAll(params),
    staleTime: 60_000,
  });
}

export function useResearchPaper(id: number) {
  return useQuery({
    queryKey: researchPapersKeys.detail(id),
    queryFn: () => researchPapersService.getById(id),
    enabled: Number.isFinite(id),
  });
}

export function useIncrementResearchPaperView(id: number) {
  return useMutation({
    mutationFn: () => researchPapersService.incrementView(id),
  });
}

export function useRateResearchPaper(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (rating: number) => researchPapersService.rate(id, rating),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: researchPapersKeys.detail(id) });
      queryClient.invalidateQueries({ queryKey: researchPapersKeys.lists() });
    },
  });
}

export function useCreateResearchPaper() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: ResearchPaperWriteDto) => researchPapersService.create(dto),
    onSuccess: (created) => {
      queryClient.setQueriesData<PaginatedResponse<ResearchPaper>>(
        { queryKey: researchPapersKeys.lists() },
        (old) =>
          old
            ? { ...old, data: [created, ...old.data], totalRecords: old.totalRecords + 1 }
            : old
      );
      queryClient.invalidateQueries({ queryKey: researchPapersKeys.lists() });
    },
  });
}

export function useUpdateResearchPaper(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: ResearchPaperWriteDto) =>
      researchPapersService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: researchPapersKeys.lists() });
      queryClient.invalidateQueries({ queryKey: researchPapersKeys.detail(id) });
    },
  });
}

export function useDeleteResearchPaper() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => researchPapersService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<PaginatedResponse<ResearchPaper>>(
        { queryKey: researchPapersKeys.lists() },
        (old) =>
          old
            ? {
                ...old,
                data: old.data.filter((p) => p.id !== id),
                totalRecords: Math.max(0, old.totalRecords - 1),
              }
            : old
      );
      queryClient.invalidateQueries({ queryKey: researchPapersKeys.lists() });
    },
  });
}

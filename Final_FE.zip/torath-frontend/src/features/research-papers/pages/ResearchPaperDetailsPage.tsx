import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { toast } from "sonner";
import {
  useResearchPaper,
  useIncrementResearchPaperView,
  useRateResearchPaper,
} from "../hooks/useResearchPapers";
import { AccessionTag } from "@/components/shared/AccessionTag";
import { CoverImage } from "@/components/shared/CoverImage";
import { PdfViewerLink } from "@/components/shared/PdfViewerLink";
import { ContentTypeBadge } from "@/components/shared/ContentTypeBadge";
import { ErrorState } from "@/components/shared/ErrorState";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { RatingInput } from "@/components/shared/RatingInput";
import { Skeleton } from "@/components/shared/Skeletons";
import { FadeIn } from "@/components/motion/FadeIn";

export function ResearchPaperDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const paperId = Number(id);
  const { data: paper, isLoading, isError, error, refetch } = useResearchPaper(paperId);
  const incrementView = useIncrementResearchPaperView(paperId);
  const ratePaper = useRateResearchPaper(paperId);

  useEffect(() => {
    if (Number.isFinite(paperId)) {
      incrementView.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paperId]);

  if (isLoading) {
    return (
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-10 md:grid-cols-[300px_1fr]">
        <Skeleton className="aspect-[4/5] w-full" />
        <div className="space-y-3">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
        </div>
      </div>
    );
  }

  if (isError || !paper) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <ErrorState
          message={error && "message" in error ? String(error.message) : undefined}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <FadeIn>
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-10 px-4 py-10 md:grid-cols-[300px_1fr]">
        <CoverImage src={paper.coverImageUrl} alt={paper.title} ratio="portrait" />

        <div>
          <div className="flex items-center gap-2">
            <ContentTypeBadge contentType="ResearchPaper" />
            <AccessionTag contentType="ResearchPaper" id={paper.id} />
          </div>

          <h1 className="mt-3 font-display text-4xl">{paper.title}</h1>
          <p className="mt-1 text-muted-foreground">{paper.author}</p>
          <RatingBadge rating={paper.rating} viewCount={paper.viewCount} className="mt-3" />
          <div className="mt-2">
            <RatingInput
              isSubmitting={ratePaper.isPending}
              onRate={(rating) =>
                ratePaper.mutate(rating, {
                  onSuccess: () => toast.success("Thanks for rating!"),
                  onError: () => toast.error("Couldn't submit your rating"),
                })
              }
            />
          </div>

          {paper.abstract && (
            <p className="mt-6 max-w-2xl text-sm leading-relaxed">
              {paper.abstract}
            </p>
          )}

          <dl className="mt-8 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3">
            <div>
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                Published
              </dt>
              <dd className="mt-0.5">{paper.publicationYear}</dd>
            </div>
            {paper.categoryName && (
              <div>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  Category
                </dt>
                <dd className="mt-0.5">{paper.categoryName}</dd>
              </div>
            )}
          </dl>

          <div className="mt-8">
            <PdfViewerLink url={paper.pdfFileUrl} />
          </div>
        </div>
      </div>
    </FadeIn>
  );
}

import { apiClient } from "@/lib/api/client";
import type { PaginatedResponse } from "@/types/common";
import type {
  ResearchPaper,
  ResearchPapersListParams,
  ResearchPaperWriteDto,
} from "../types";

export const researchPapersService = {
  getAll: async (
    params: ResearchPapersListParams
  ): Promise<PaginatedResponse<ResearchPaper>> => {
    const { data } = await apiClient.get<PaginatedResponse<ResearchPaper>>(
      "/api/ResearchPapers",
      { params }
    );
    return data;
  },
  getById: async (id: number): Promise<ResearchPaper> => {
    const { data } = await apiClient.get<ResearchPaper>(
      `/api/ResearchPapers/${id}`
    );
    return data;
  },
  create: async (dto: ResearchPaperWriteDto): Promise<ResearchPaper> => {
    const { data } = await apiClient.post<ResearchPaper>(
      "/api/ResearchPapers",
      dto
    );
    return data;
  },
  update: async (id: number, dto: ResearchPaperWriteDto): Promise<void> => {
    await apiClient.put(`/api/ResearchPapers/${id}`, dto);
  },
  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/ResearchPapers/${id}`);
  },

  incrementView: async (id: number): Promise<void> => {
    await apiClient.post(`/api/ResearchPapers/${id}/view`);
  },

  rate: async (id: number, rating: number): Promise<void> => {
    await apiClient.post(`/api/ResearchPapers/${id}/rate`, rating);
  },
};

/** Matches ResearchPaperWriteDto exactly. Has BOTH coverImageUrl and pdfFileUrl. */
export type ResearchPaperWriteDto = {
  title: string; // required, 1–200 chars
  abstract?: string | null;
  author: string; // required, 1–200 chars
  publicationYear: number;
  categoryId: number;
  coverImageUrl?: string | null;
  pdfFileUrl?: string | null;
};

/**
 * Confirmed against ResearchPaperDto + ResearchPaperService (2026-08-07).
 * categoryName is flat and reliably populated. coverImageUrl/pdfFileUrl
 * round-trip correctly. Rating/ViewCount are now mapped in the Select
 * projection too — previously always read back as 0, now reliable.
 */
export type ResearchPaper = ResearchPaperWriteDto & {
  id: number;
  categoryName: string;
  rating: number;
  viewCount: number;
};

export type ResearchPapersListParams = {
  page?: number;
  pageSize?: number;
  publicationYear?: number;
};

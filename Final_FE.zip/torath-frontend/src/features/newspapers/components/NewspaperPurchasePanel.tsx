import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { CreditCard, Download, Loader2 } from "lucide-react";
import { useAuthStore } from "@/features/auth/store";
import {
  useNewspaperCheckout,
  useNewspaperDownload,
  useNewspaperOwnership,
} from "../hooks/useNewspapers";
import { toApiError } from "@/lib/api/errors";
import { Button } from "@/components/ui/button";

type OwnershipState = "checking" | "not-owned" | "owned";

export function NewspaperPurchasePanel({
  newspaperId,
  price,
}: {
  newspaperId: number;
  price: number;
}) {
  const [searchParams, setSearchParams] = useSearchParams();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isAdmin = useAuthStore((s) => s.session?.isAdmin ?? false);

  // GET /{id}/ownership gives the real initial state — only needed for
  // non-admin authenticated users (Admins bypass via role; guests can't
  // own anything). Skips the network call entirely for the other two cases.
  const ownershipQuery = useNewspaperOwnership(
    newspaperId,
    isAuthenticated && !isAdmin
  );
  const [ownership, setOwnership] = useState<OwnershipState>("checking");

  useEffect(() => {
    if (ownershipQuery.data !== undefined) {
      setOwnership(ownershipQuery.data ? "owned" : "not-owned");
    }
  }, [ownershipQuery.data]);

  const checkout = useNewspaperCheckout(newspaperId);
  const download = useNewspaperDownload(newspaperId);

  const triggerDownload = (isRetryAfterPayment = false) => {
    download.mutate(undefined, {
      onSuccess: () => {
        setOwnership("owned");
        toast.success("Download started");
      },
      onError: (error) => {
        const apiError = toApiError(error);
        if (apiError.status === 403 && isRetryAfterPayment) {
          // Webhook likely hasn't landed yet — one automatic retry.
          toast.message("Confirming your payment…", {
            description: "This can take a few seconds.",
          });
          setTimeout(() => triggerDownload(false), 3000);
        } else if (apiError.status === 403) {
          toast.error("Payment not confirmed yet — try again in a moment.");
        } else {
          toast.error(apiError.message);
        }
      },
    });
  };

  useEffect(() => {
    if (searchParams.get("success") === "true") {
      setOwnership("owned");
      triggerDownload(true);
      searchParams.delete("success");
      setSearchParams(searchParams, { replace: true });
    } else if (searchParams.get("canceled") === "true") {
      toast.message("Payment canceled");
      searchParams.delete("canceled");
      setSearchParams(searchParams, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleBuyClick = () => {
    checkout.mutate(undefined, {
      onSuccess: (data) => {
        window.location.href = data.url;
      },
      onError: (error) => {
        // Safety net: the ownership check should already prevent this
        // path, but if it was stale for any reason, recover gracefully
        // instead of showing a raw error.
        const message = toApiError(error).message;
        if (message.toLowerCase().includes("already own")) {
          setOwnership("owned");
          triggerDownload(false);
        } else {
          toast.error(message);
        }
      },
    });
  };

  if (!isAuthenticated) {
    return (
      <p className="text-sm text-muted-foreground">
        Sign in to purchase and download this newspaper.
      </p>
    );
  }

  if (!isAdmin && ownership === "checking") {
    return (
      <Button disabled>
        <Loader2 className="h-4 w-4 animate-spin" />
        Checking…
      </Button>
    );
  }

  if (isAdmin || ownership === "owned") {
    return (
      <Button onClick={() => triggerDownload(false)} disabled={download.isPending}>
        {download.isPending ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Download className="h-4 w-4" />
        )}
        {isAdmin ? "Download (Admin)" : "Download PDF"}
      </Button>
    );
  }

  return (
    <Button onClick={handleBuyClick} disabled={checkout.isPending}>
      {checkout.isPending ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <CreditCard className="h-4 w-4" />
      )}
      Buy for ${price.toFixed(2)}
    </Button>
  );
}

/** Matches NewspaperWriteDto exactly (confirmed 2026-08-07). Accepts coverImageUrl too. */
export type NewspaperWriteDto = {
  title?: string | null;
  description?: string | null;
  language?: string | null;
  publicationDate: string;
  publisher?: string | null;
  categoryId: number;
  frequency?: string | null;
  price: number;
  pdfFilePath?: string | null;
  coverImageUrl?: string | null;
};

/**
 * Confirmed against DTOs/NewspaperReadDto.cs + NewspaperService's Select
 * projection (2026-08-07) — description, publicationDate, categoryName,
 * and coverImageUrl are all now mapped on both GetAll and GetById. This
 * was the most incomplete read DTO in the API; all four gaps are closed.
 */
export type Newspaper = {
  id: number;
  title: string;
  description: string;
  publicationDate: string;
  publisher: string;
  frequency: string;
  language: string;
  price: number;
  categoryId: number;
  categoryName: string;
  pdfFilePath: string | null;
  coverImageUrl: string | null;
  rating: number;
  viewCount: number;
};

export type NewspaperIssueWriteDto = {
  issueNumber?: string | null;
  publicationDate: string;
  newspaperId: number;
};

export type NewspaperIssue = NewspaperIssueWriteDto & {
  id: number;
  rating: number;
  viewCount: number;
};

export type NewspapersListParams = {
  page?: number;
  pageSize?: number;
};

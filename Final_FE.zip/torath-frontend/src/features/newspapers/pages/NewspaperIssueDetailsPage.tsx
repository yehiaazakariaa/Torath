import { useParams } from "react-router-dom";
import { useNewspaperIssue } from "../hooks/useNewspapers";
import { AccessionTag } from "@/components/shared/AccessionTag";
import { ContentTypeBadge } from "@/components/shared/ContentTypeBadge";
import { ErrorState } from "@/components/shared/ErrorState";
import { Skeleton } from "@/components/shared/Skeletons";
import { FadeIn } from "@/components/motion/FadeIn";

export function NewspaperIssueDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const issueId = Number(id);
  const { data: issue, isLoading, isError, error, refetch } = useNewspaperIssue(issueId);

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl space-y-3 px-4 py-10">
        <Skeleton className="h-8 w-1/2" />
        <Skeleton className="h-4 w-1/3" />
      </div>
    );
  }

  if (isError || !issue) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <ErrorState
          message={error && "message" in error ? String(error.message) : undefined}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <FadeIn>
      <div className="mx-auto max-w-3xl px-4 py-10">
        <div className="flex items-center gap-2">
          <ContentTypeBadge contentType="NewspaperIssue" />
          <AccessionTag contentType="NewspaperIssue" id={issue.id} />
        </div>
        <h1 className="mt-3 font-display text-4xl">Issue {issue.issueNumber}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Published {new Date(issue.publicationDate).toLocaleDateString()}
        </p>
      </div>
    </FadeIn>
  );
}

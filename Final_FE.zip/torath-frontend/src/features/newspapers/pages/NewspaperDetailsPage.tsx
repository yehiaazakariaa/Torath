import { useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import { useNewspaper, useNewspaperIssues, useIncrementNewspaperView, useRateNewspaper } from "../hooks/useNewspapers";
import { AccessionTag } from "@/components/shared/AccessionTag";
import { CoverImage } from "@/components/shared/CoverImage";
import { NewspaperPurchasePanel } from "../components/NewspaperPurchasePanel";
import { ContentTypeBadge } from "@/components/shared/ContentTypeBadge";
import { ErrorState } from "@/components/shared/ErrorState";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { RatingInput } from "@/components/shared/RatingInput";
import { Skeleton } from "@/components/shared/Skeletons";
import { FadeIn } from "@/components/motion/FadeIn";

export function NewspaperDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const newspaperId = Number(id);
  const {
    data: newspaper,
    isLoading,
    isError,
    error,
    refetch,
  } = useNewspaper(newspaperId);
  const { data: issues } = useNewspaperIssues(newspaperId);
  const incrementView = useIncrementNewspaperView(newspaperId);
  const rateNewspaper = useRateNewspaper(newspaperId);

  useEffect(() => {
    if (Number.isFinite(newspaperId)) {
      incrementView.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [newspaperId]);

  if (isLoading) {
    return (
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-10 md:grid-cols-[300px_1fr]">
        <Skeleton className="aspect-[16/10] w-full" />
        <div className="space-y-3">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
        </div>
      </div>
    );
  }

  if (isError || !newspaper) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <ErrorState
          message={error && "message" in error ? String(error.message) : undefined}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <FadeIn>
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-10 px-4 py-10 md:grid-cols-[300px_1fr]">
        <CoverImage src={newspaper.coverImageUrl} alt={newspaper.title} ratio="wide" />

        <div>
          <div className="flex items-center gap-2">
            <ContentTypeBadge contentType="Newspaper" />
            <AccessionTag contentType="Newspaper" id={newspaper.id} />
          </div>

          <h1 className="mt-3 font-display text-4xl">{newspaper.title}</h1>
          {newspaper.categoryName && (
            <p className="mt-1 text-xs uppercase tracking-wide text-accent">
              {newspaper.categoryName}
            </p>
          )}
          <RatingBadge rating={newspaper.rating} viewCount={newspaper.viewCount} className="mt-3" />
          <div className="mt-2">
            <RatingInput
              isSubmitting={rateNewspaper.isPending}
              onRate={(rating) =>
                rateNewspaper.mutate(rating, {
                  onSuccess: () => toast.success("Thanks for rating!"),
                  onError: () => toast.error("Couldn't submit your rating"),
                })
              }
            />
          </div>
          {newspaper.description && (
            <p className="mt-6 max-w-2xl text-sm leading-relaxed">
              {newspaper.description}
            </p>
          )}

          <dl className="mt-8 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3">
            {newspaper.frequency && (
              <div>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  Frequency
                </dt>
                <dd className="mt-0.5">{newspaper.frequency}</dd>
              </div>
            )}
            {newspaper.language && (
              <div>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  Language
                </dt>
                <dd className="mt-0.5">{newspaper.language}</dd>
              </div>
            )}
            {newspaper.publisher && (
              <div>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  Publisher
                </dt>
                <dd className="mt-0.5">{newspaper.publisher}</dd>
              </div>
            )}
            <div>
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                Published
              </dt>
              <dd className="mt-0.5">
                {new Date(newspaper.publicationDate).toLocaleDateString()}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                Price
              </dt>
              <dd className="mt-0.5">${newspaper.price.toFixed(2)}</dd>
            </div>
          </dl>

          <div className="mt-6">
            <NewspaperPurchasePanel newspaperId={newspaper.id} price={newspaper.price} />
          </div>

          {issues && issues.length > 0 && (
            <div className="mt-10">
              <h2 className="font-display text-xl">Issues</h2>
              <ul className="mt-3 space-y-2">
                {issues.map((issue) => (
                  <li key={issue.id}>
                    <Link
                      to={`/newspapers/${newspaper.id}/issues/${issue.id}`}
                      className="flex items-center justify-between rounded border border-border px-4 py-2 text-sm hover:bg-muted"
                    >
                      <span>Issue {issue.issueNumber}</span>
                      <AccessionTag contentType="NewspaperIssue" id={issue.id} />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </FadeIn>
  );
}

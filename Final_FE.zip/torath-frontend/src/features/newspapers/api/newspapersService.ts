import { apiClient } from "@/lib/api/client";
import type { PaginatedResponse } from "@/types/common";
import type {
  Newspaper,
  NewspaperIssue,
  NewspaperIssueWriteDto,
  NewspapersListParams,
  NewspaperWriteDto,
} from "../types";

export const newspapersService = {
  getAll: async (
    params: NewspapersListParams
  ): Promise<PaginatedResponse<Newspaper>> => {
    const { data } = await apiClient.get<PaginatedResponse<Newspaper>>(
      "/api/Newspapers",
      { params }
    );
    return data;
  },
  getById: async (id: number): Promise<Newspaper> => {
    const { data } = await apiClient.get<Newspaper>(`/api/Newspapers/${id}`);
    return data;
  },
  getIssues: async (
    newspaperId: number
  ): Promise<NewspaperIssue[] | PaginatedResponse<NewspaperIssue>> => {
    const { data } = await apiClient.get(
      `/api/Newspapers/${newspaperId}/issues`
    );
    return data;
  },
  create: async (dto: NewspaperWriteDto): Promise<Newspaper> => {
    const { data } = await apiClient.post<Newspaper>("/api/Newspapers", dto);
    return data;
  },
  update: async (id: number, dto: NewspaperWriteDto): Promise<void> => {
    await apiClient.put(`/api/Newspapers/${id}`, dto);
  },
  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/Newspapers/${id}`);
  },

  incrementView: async (id: number): Promise<void> => {
    await apiClient.post(`/api/Newspapers/${id}/view`);
  },

  rate: async (id: number, rating: number): Promise<void> => {
    await apiClient.post(`/api/Newspapers/${id}/rate`, rating);
  },

  /** Requires auth. Returns a Stripe Checkout URL to redirect to, or
   * throws a 400 if the user already owns this newspaper. */
  checkout: async (id: number): Promise<{ url: string }> => {
    const { data } = await apiClient.post<{ url: string }>(
      `/api/Newspapers/${id}/checkout`
    );
    return data;
  },

  /** Requires auth. 403 if not purchased (and not Admin). Returns the raw PDF bytes. */
  download: async (id: number): Promise<{ blob: Blob; filename: string | null }> => {
    const response = await apiClient.get(`/api/Newspapers/${id}/download`, {
      responseType: "blob",
    });
    const disposition: string | undefined = response.headers["content-disposition"];
    const match = disposition?.match(/filename="?([^";]+)"?/i);
    return { blob: response.data, filename: match?.[1] ?? null };
  },

  /** Admin-only. Confirmed against Controllers/NewspapersController.cs GetAnalytics. */
  getPaymentAnalytics: async (): Promise<{ totalDownloads: number; totalRevenue: number }> => {
    const { data } = await apiClient.get<{ totalDownloads: number; totalRevenue: number }>(
      "/api/Newspapers/admin/analytics"
    );
    return data;
  },

  /** Requires User/Admin auth. Only reflects UserPurchases — always false for Admins, who bypass via role instead. */
  checkOwnership: async (id: number): Promise<boolean> => {
    const { data } = await apiClient.get<{ isOwned: boolean }>(
      `/api/Newspapers/${id}/ownership`
    );
    return data.isOwned;
  },
};

export const newspaperIssuesService = {
  getById: async (id: number): Promise<NewspaperIssue> => {
    const { data } = await apiClient.get<NewspaperIssue>(
      `/api/NewspaperIssues/${id}`
    );
    return data;
  },
  create: async (dto: NewspaperIssueWriteDto): Promise<NewspaperIssue> => {
    const { data } = await apiClient.post<NewspaperIssue>(
      "/api/NewspaperIssues",
      dto
    );
    return data;
  },
  update: async (id: number, dto: NewspaperIssueWriteDto): Promise<void> => {
    await apiClient.put(`/api/NewspaperIssues/${id}`, dto);
  },
  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/NewspaperIssues/${id}`);
  },
  getArticles: async (issueId: number) => {
    const { data } = await apiClient.get(
      `/api/NewspaperIssues/${issueId}/articles`
    );
    return data;
  },
};

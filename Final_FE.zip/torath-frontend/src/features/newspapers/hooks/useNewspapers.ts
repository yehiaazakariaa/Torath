import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  newspapersService,
  newspaperIssuesService,
} from "../api/newspapersService";
import type {
  Newspaper,
  NewspaperIssue,
  NewspaperIssueWriteDto,
  NewspapersListParams,
  NewspaperWriteDto,
} from "../types";
import type { PaginatedResponse } from "@/types/common";

export const newspapersKeys = {
  all: ["newspapers"] as const,
  lists: () => [...newspapersKeys.all, "list"] as const,
  list: (params: NewspapersListParams) =>
    [...newspapersKeys.lists(), params] as const,
  details: () => [...newspapersKeys.all, "detail"] as const,
  detail: (id: number) => [...newspapersKeys.details(), id] as const,
  issues: (id: number) => [...newspapersKeys.detail(id), "issues"] as const,
};

export function useNewspapers(params: NewspapersListParams) {
  return useQuery({
    queryKey: newspapersKeys.list(params),
    queryFn: () => newspapersService.getAll(params),
    staleTime: 60_000,
  });
}

export function useNewspaper(id: number) {
  return useQuery({
    queryKey: newspapersKeys.detail(id),
    queryFn: () => newspapersService.getById(id),
    enabled: Number.isFinite(id),
  });
}

export function useIncrementNewspaperView(id: number) {
  return useMutation({
    mutationFn: () => newspapersService.incrementView(id),
  });
}

export function useRateNewspaper(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (rating: number) => newspapersService.rate(id, rating),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: newspapersKeys.detail(id) });
      queryClient.invalidateQueries({ queryKey: newspapersKeys.lists() });
    },
  });
}

/** Redirects to Stripe on success. Throws (with the backend's message) if already owned. */
export function useNewspaperCheckout(id: number) {
  return useMutation({
    mutationFn: () => newspapersService.checkout(id),
  });
}

/** Triggers a browser file-save from the returned blob. */
export function useNewspaperDownload(id: number) {
  return useMutation({
    mutationFn: async () => {
      const { blob, filename } = await newspapersService.download(id);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename ?? "newspaper.pdf";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    },
  });
}

export function useNewspaperPaymentAnalytics() {
  return useQuery({
    queryKey: ["newspapers", "admin", "analytics"],
    queryFn: newspapersService.getPaymentAnalytics,
    staleTime: 60_000,
  });
}

export function useNewspaperOwnership(id: number, enabled: boolean) {
  return useQuery({
    queryKey: ["newspapers", "ownership", id],
    queryFn: () => newspapersService.checkOwnership(id),
    enabled: enabled && Number.isFinite(id),
    staleTime: 0, // ownership can change any time a purchase completes — never trust a stale cached value
  });
}

export function useNewspaperIssues(newspaperId: number) {
  return useQuery({
    queryKey: newspapersKeys.issues(newspaperId),
    queryFn: async () => {
      const result = await newspapersService.getIssues(newspaperId);
      return Array.isArray(result) ? result : result.data;
    },
    enabled: Number.isFinite(newspaperId),
  });
}

export function useNewspaperIssue(id: number) {
  return useQuery({
    queryKey: [...newspapersKeys.all, "issue", id] as const,
    queryFn: () => newspaperIssuesService.getById(id),
    enabled: Number.isFinite(id),
  });
}

export function useCreateNewspaper() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: NewspaperWriteDto) => newspapersService.create(dto),
    onSuccess: (created) => {
      queryClient.setQueriesData<PaginatedResponse<Newspaper>>(
        { queryKey: newspapersKeys.lists() },
        (old) =>
          old
            ? { ...old, data: [created, ...old.data], totalRecords: old.totalRecords + 1 }
            : old
      );
      queryClient.invalidateQueries({ queryKey: newspapersKeys.lists() });
    },
  });
}

export function useUpdateNewspaper(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: NewspaperWriteDto) => newspapersService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: newspapersKeys.lists() });
      queryClient.invalidateQueries({ queryKey: newspapersKeys.detail(id) });
    },
  });
}

export function useDeleteNewspaper() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => newspapersService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<PaginatedResponse<Newspaper>>(
        { queryKey: newspapersKeys.lists() },
        (old) =>
          old
            ? {
                ...old,
                data: old.data.filter((n) => n.id !== id),
                totalRecords: Math.max(0, old.totalRecords - 1),
              }
            : old
      );
      queryClient.invalidateQueries({ queryKey: newspapersKeys.lists() });
    },
  });
}

export function useCreateNewspaperIssue() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: NewspaperIssueWriteDto) => newspaperIssuesService.create(dto),
    onSuccess: (_created, dto) => {
      queryClient.invalidateQueries({ queryKey: newspapersKeys.issues(dto.newspaperId) });
    },
  });
}

export function useUpdateNewspaperIssue(id: number, newspaperId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: NewspaperIssueWriteDto) => newspaperIssuesService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: newspapersKeys.issues(newspaperId) });
    },
  });
}

export function useDeleteNewspaperIssue(newspaperId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => newspaperIssuesService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<NewspaperIssue[]>(
        { queryKey: newspapersKeys.issues(newspaperId) },
        (old) => old?.filter((issue) => issue.id !== id)
      );
      queryClient.invalidateQueries({ queryKey: newspapersKeys.issues(newspaperId) });
    },
  });
}

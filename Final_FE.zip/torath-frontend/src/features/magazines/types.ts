/** Matches MagazineWriteDto exactly (confirmed 2026-08-07). Accepts coverImageUrl/pdfFileUrl. */
export type MagazineWriteDto = {
  title?: string | null;
  description?: string | null;
  language?: string | null;
  publicationDate: string;
  publisher?: string | null;
  categoryId: number;
  issn?: string | null;
  coverImageUrl?: string | null;
  pdfFileUrl?: string | null;
};

/**
 * Confirmed against MagazineDto + MagazineService's Select projection
 * (2026-08-07) — coverImageUrl/pdfFileUrl are now mapped on both GetAll
 * and GetById, so uploads round-trip correctly on read.
 *
 * Still true: flat `categoryName`, no createdDate/updatedDate.
 */
export type Magazine = {
  id: number;
  title: string;
  description: string;
  language: string;
  publisher: string;
  publicationDate: string;
  categoryId: number;
  categoryName: string;
  issn: string;
  rating: number;
  viewCount: number;
  coverImageUrl: string | null;
  pdfFileUrl: string | null;
};

export type MagazineIssueWriteDto = {
  issueNumber?: string | null;
  volumeNumber?: string | null;
  publicationDate: string;
  magazineId: number;
};

/**
 * Two shapes exist for this entity depending on the endpoint:
 * - `GET /api/Magazines/{id}/issues` (nested) → MagazineIssueDto
 * - `GET /api/MagazineIssues/{id}` (top-level single) → raw entity
 * Both expose the same usable fields; nav props on the raw entity stay
 * null/empty (no Include) and aren't modeled since nothing uses them.
 */
export type MagazineIssue = MagazineIssueWriteDto & {
  id: number;
  rating: number;
  viewCount: number;
};

export type MagazinesListParams = {
  page?: number;
  pageSize?: number;
};

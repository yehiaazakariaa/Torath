import { useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import { useMagazine, useMagazineIssues, useIncrementMagazineView, useRateMagazine } from "../hooks/useMagazines";
import { AccessionTag } from "@/components/shared/AccessionTag";
import { CoverImage } from "@/components/shared/CoverImage";
import { PdfViewerLink } from "@/components/shared/PdfViewerLink";
import { ContentTypeBadge } from "@/components/shared/ContentTypeBadge";
import { ErrorState } from "@/components/shared/ErrorState";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { RatingInput } from "@/components/shared/RatingInput";
import { Skeleton } from "@/components/shared/Skeletons";
import { FadeIn } from "@/components/motion/FadeIn";

export function MagazineDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const magazineId = Number(id);
  const {
    data: magazine,
    isLoading,
    isError,
    error,
    refetch,
  } = useMagazine(magazineId);
  const { data: issues } = useMagazineIssues(magazineId);
  const incrementView = useIncrementMagazineView(magazineId);
  const rateMagazine = useRateMagazine(magazineId);

  useEffect(() => {
    if (Number.isFinite(magazineId)) {
      incrementView.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [magazineId]);

  if (isLoading) {
    return (
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-10 md:grid-cols-[300px_1fr]">
        <Skeleton className="aspect-[16/10] w-full" />
        <div className="space-y-3">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
        </div>
      </div>
    );
  }

  if (isError || !magazine) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <ErrorState
          message={error && "message" in error ? String(error.message) : undefined}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <FadeIn>
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-10 px-4 py-10 md:grid-cols-[300px_1fr]">
        <CoverImage src={magazine.coverImageUrl} alt={magazine.title} ratio="wide" />

        <div>
          <div className="flex items-center gap-2">
            <ContentTypeBadge contentType="Magazine" />
            <AccessionTag contentType="Magazine" id={magazine.id} />
          </div>

          <h1 className="mt-3 font-display text-4xl">{magazine.title}</h1>
          {magazine.categoryName && (
            <p className="mt-1 text-xs uppercase tracking-wide text-accent">
              {magazine.categoryName}
            </p>
          )}
          <RatingBadge rating={magazine.rating} viewCount={magazine.viewCount} className="mt-3" />
          <div className="mt-2">
            <RatingInput
              isSubmitting={rateMagazine.isPending}
              onRate={(rating) =>
                rateMagazine.mutate(rating, {
                  onSuccess: () => toast.success("Thanks for rating!"),
                  onError: () => toast.error("Couldn't submit your rating"),
                })
              }
            />
          </div>
          {magazine.description && (
            <p className="mt-6 max-w-2xl text-sm leading-relaxed">
              {magazine.description}
            </p>
          )}

          <dl className="mt-8 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3">
            {magazine.issn && (
              <div>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  ISSN
                </dt>
                <dd className="mt-0.5">{magazine.issn}</dd>
              </div>
            )}
            {magazine.language && (
              <div>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  Language
                </dt>
                <dd className="mt-0.5">{magazine.language}</dd>
              </div>
            )}
            {magazine.publisher && (
              <div>
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  Publisher
                </dt>
                <dd className="mt-0.5">{magazine.publisher}</dd>
              </div>
            )}
          </dl>

          <div className="mt-6">
            <PdfViewerLink url={magazine.pdfFileUrl} />
          </div>

          {issues && issues.length > 0 && (
            <div className="mt-10">
              <h2 className="font-display text-xl">Issues</h2>
              <ul className="mt-3 space-y-2">
                {issues.map((issue) => (
                  <li key={issue.id}>
                    <Link
                      to={`/magazines/${magazine.id}/issues/${issue.id}`}
                      className="flex items-center justify-between rounded border border-border px-4 py-2 text-sm hover:bg-muted"
                    >
                      <span>
                        Issue {issue.issueNumber}
                        {issue.volumeNumber && ` · Vol. ${issue.volumeNumber}`}
                      </span>
                      <AccessionTag contentType="MagazineIssue" id={issue.id} />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </FadeIn>
  );
}

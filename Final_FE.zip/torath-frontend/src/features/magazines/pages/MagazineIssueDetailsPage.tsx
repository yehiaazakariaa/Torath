import { useParams } from "react-router-dom";
import { useMagazineIssue } from "../hooks/useMagazines";
import { AccessionTag } from "@/components/shared/AccessionTag";
import { ContentTypeBadge } from "@/components/shared/ContentTypeBadge";
import { ErrorState } from "@/components/shared/ErrorState";
import { Skeleton } from "@/components/shared/Skeletons";
import { FadeIn } from "@/components/motion/FadeIn";

export function MagazineIssueDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const issueId = Number(id);
  const { data: issue, isLoading, isError, error, refetch } = useMagazineIssue(issueId);

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl space-y-3 px-4 py-10">
        <Skeleton className="h-8 w-1/2" />
        <Skeleton className="h-4 w-1/3" />
      </div>
    );
  }

  if (isError || !issue) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <ErrorState
          message={error && "message" in error ? String(error.message) : undefined}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <FadeIn>
      <div className="mx-auto max-w-3xl px-4 py-10">
        <div className="flex items-center gap-2">
          <ContentTypeBadge contentType="MagazineIssue" />
          <AccessionTag contentType="MagazineIssue" id={issue.id} />
        </div>
        <h1 className="mt-3 font-display text-4xl">
          Issue {issue.issueNumber}
          {issue.volumeNumber && ` · Vol. ${issue.volumeNumber}`}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Published {new Date(issue.publicationDate).toLocaleDateString()}
        </p>
        {/* Articles for this issue are available via useMagazineIssues'
            sibling endpoint (MagazineIssuesController.GetArticles) — not
            wired here yet since ArticlesController + this list need a
            shared ArticleList component (Phase 4/6 follow-up). */}
      </div>
    </FadeIn>
  );
}

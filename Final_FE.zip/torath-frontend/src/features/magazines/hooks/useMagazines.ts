import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { magazinesService, magazineIssuesService } from "../api/magazinesService";
import type {
  Magazine,
  MagazineIssue,
  MagazineIssueWriteDto,
  MagazinesListParams,
  MagazineWriteDto,
} from "../types";
import type { PaginatedResponse } from "@/types/common";

export const magazinesKeys = {
  all: ["magazines"] as const,
  lists: () => [...magazinesKeys.all, "list"] as const,
  list: (params: MagazinesListParams) =>
    [...magazinesKeys.lists(), params] as const,
  details: () => [...magazinesKeys.all, "detail"] as const,
  detail: (id: number) => [...magazinesKeys.details(), id] as const,
  issues: (id: number) => [...magazinesKeys.detail(id), "issues"] as const,
};

export function useMagazines(params: MagazinesListParams) {
  return useQuery({
    queryKey: magazinesKeys.list(params),
    queryFn: () => magazinesService.getAll(params),
    staleTime: 60_000,
  });
}

export function useMagazine(id: number) {
  return useQuery({
    queryKey: magazinesKeys.detail(id),
    queryFn: () => magazinesService.getById(id),
    enabled: Number.isFinite(id),
  });
}

export function useIncrementMagazineView(id: number) {
  return useMutation({
    mutationFn: () => magazinesService.incrementView(id),
  });
}

export function useRateMagazine(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (rating: number) => magazinesService.rate(id, rating),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: magazinesKeys.detail(id) });
      queryClient.invalidateQueries({ queryKey: magazinesKeys.lists() });
    },
  });
}

export function useMagazineIssues(magazineId: number) {
  return useQuery({
    queryKey: magazinesKeys.issues(magazineId),
    queryFn: async () => {
      const result = await magazinesService.getIssues(magazineId);
      return Array.isArray(result) ? result : result.data;
    },
    enabled: Number.isFinite(magazineId),
  });
}

export function useMagazineIssue(id: number) {
  return useQuery({
    queryKey: [...magazinesKeys.all, "issue", id] as const,
    queryFn: () => magazineIssuesService.getById(id),
    enabled: Number.isFinite(id),
  });
}

export function useCreateMagazine() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: MagazineWriteDto) => magazinesService.create(dto),
    onSuccess: (created) => {
      queryClient.setQueriesData<PaginatedResponse<Magazine>>(
        { queryKey: magazinesKeys.lists() },
        (old) =>
          old
            ? { ...old, data: [created, ...old.data], totalRecords: old.totalRecords + 1 }
            : old
      );
      queryClient.invalidateQueries({ queryKey: magazinesKeys.lists() });
    },
  });
}

export function useUpdateMagazine(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: MagazineWriteDto) => magazinesService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: magazinesKeys.lists() });
      queryClient.invalidateQueries({ queryKey: magazinesKeys.detail(id) });
    },
  });
}

export function useDeleteMagazine() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => magazinesService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<PaginatedResponse<Magazine>>(
        { queryKey: magazinesKeys.lists() },
        (old) =>
          old
            ? {
                ...old,
                data: old.data.filter((m) => m.id !== id),
                totalRecords: Math.max(0, old.totalRecords - 1),
              }
            : old
      );
      queryClient.invalidateQueries({ queryKey: magazinesKeys.lists() });
    },
  });
}

export function useCreateMagazineIssue() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: MagazineIssueWriteDto) => magazineIssuesService.create(dto),
    onSuccess: (_created, dto) => {
      queryClient.invalidateQueries({ queryKey: magazinesKeys.issues(dto.magazineId) });
    },
  });
}

export function useUpdateMagazineIssue(id: number, magazineId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: MagazineIssueWriteDto) => magazineIssuesService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: magazinesKeys.issues(magazineId) });
    },
  });
}

export function useDeleteMagazineIssue(magazineId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => magazineIssuesService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<MagazineIssue[]>(
        { queryKey: magazinesKeys.issues(magazineId) },
        (old) => old?.filter((issue) => issue.id !== id)
      );
      queryClient.invalidateQueries({ queryKey: magazinesKeys.issues(magazineId) });
    },
  });
}

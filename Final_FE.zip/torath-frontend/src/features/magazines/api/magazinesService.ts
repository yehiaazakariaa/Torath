import { apiClient } from "@/lib/api/client";
import type { PaginatedResponse } from "@/types/common";
import type {
  Magazine,
  MagazineIssue,
  MagazineIssueWriteDto,
  MagazinesListParams,
  MagazineWriteDto,
} from "../types";

export const magazinesService = {
  getAll: async (
    params: MagazinesListParams
  ): Promise<PaginatedResponse<Magazine>> => {
    const { data } = await apiClient.get<PaginatedResponse<Magazine>>(
      "/api/Magazines",
      { params }
    );
    return data;
  },
  getById: async (id: number): Promise<Magazine> => {
    const { data } = await apiClient.get<Magazine>(`/api/Magazines/${id}`);
    return data;
  },
  getIssues: async (
    magazineId: number
  ): Promise<MagazineIssue[] | PaginatedResponse<MagazineIssue>> => {
    // Response shape for this nested endpoint is unconfirmed — could be a
    // bare array or the standard paginated envelope. Callers should
    // handle both (see useMagazineIssues).
    const { data } = await apiClient.get(
      `/api/Magazines/${magazineId}/issues`
    );
    return data;
  },
  create: async (dto: MagazineWriteDto): Promise<Magazine> => {
    const { data } = await apiClient.post<Magazine>("/api/Magazines", dto);
    return data;
  },
  update: async (id: number, dto: MagazineWriteDto): Promise<void> => {
    await apiClient.put(`/api/Magazines/${id}`, dto);
  },
  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/Magazines/${id}`);
  },

  incrementView: async (id: number): Promise<void> => {
    await apiClient.post(`/api/Magazines/${id}/view`);
  },

  rate: async (id: number, rating: number): Promise<void> => {
    await apiClient.post(`/api/Magazines/${id}/rate`, rating);
  },
};

export const magazineIssuesService = {
  getById: async (id: number): Promise<MagazineIssue> => {
    const { data } = await apiClient.get<MagazineIssue>(
      `/api/MagazineIssues/${id}`
    );
    return data;
  },
  create: async (dto: MagazineIssueWriteDto): Promise<MagazineIssue> => {
    const { data } = await apiClient.post<MagazineIssue>(
      "/api/MagazineIssues",
      dto
    );
    return data;
  },
  update: async (id: number, dto: MagazineIssueWriteDto): Promise<void> => {
    await apiClient.put(`/api/MagazineIssues/${id}`, dto);
  },
  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/MagazineIssues/${id}`);
  },
  getArticles: async (issueId: number) => {
    const { data } = await apiClient.get(
      `/api/MagazineIssues/${issueId}/articles`
    );
    return data;
  },
};

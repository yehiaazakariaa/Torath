export type CategoryWriteDto = {
  name: string; // required, 1–100 chars
  description?: string | null; // max 500 chars
};

/** Confirmed against Entities/Category.cs — no createdDate/updatedDate on this entity. */
export type Category = CategoryWriteDto & {
  id: number;
};

export type CategoriesListParams = {
  page?: number;
  pageSize?: number;
  search?: string;
};

import { apiClient } from "@/lib/api/client";
import type { PaginatedResponse } from "@/types/common";
import type { Category, CategoriesListParams, CategoryWriteDto } from "../types";

export const categoriesService = {
  getAll: async (
    params: CategoriesListParams
  ): Promise<PaginatedResponse<Category>> => {
    const { data } = await apiClient.get<PaginatedResponse<Category>>(
      "/api/Categories",
      { params }
    );
    return data;
  },
  getById: async (id: number): Promise<Category> => {
    const { data } = await apiClient.get<Category>(`/api/Categories/${id}`);
    return data;
  },
  create: async (dto: CategoryWriteDto): Promise<Category> => {
    const { data } = await apiClient.post<Category>("/api/Categories", dto);
    return data;
  },
  update: async (id: number, dto: CategoryWriteDto): Promise<void> => {
    await apiClient.put(`/api/Categories/${id}`, dto);
  },
  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/Categories/${id}`);
  },
};

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { categoriesService } from "../api/categoriesService";
import type { Category, CategoriesListParams, CategoryWriteDto } from "../types";
import type { PaginatedResponse } from "@/types/common";

export const categoriesKeys = {
  all: ["categories"] as const,
  lists: () => [...categoriesKeys.all, "list"] as const,
  list: (params: CategoriesListParams) =>
    [...categoriesKeys.lists(), params] as const,
};

export function useCategories(params: CategoriesListParams = {}) {
  return useQuery({
    queryKey: categoriesKeys.list(params),
    queryFn: () => categoriesService.getAll(params),
    staleTime: 5 * 60_000, // categories change rarely
  });
}

export function useCreateCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: CategoryWriteDto) => categoriesService.create(dto),
    onSuccess: (created) => {
      queryClient.setQueriesData<PaginatedResponse<Category>>(
        { queryKey: categoriesKeys.lists() },
        (old) =>
          old
            ? { ...old, data: [created, ...old.data], totalRecords: old.totalRecords + 1 }
            : old
      );
      queryClient.invalidateQueries({ queryKey: categoriesKeys.lists() });
    },
  });
}

export function useUpdateCategory(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: CategoryWriteDto) => categoriesService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: categoriesKeys.lists() });
    },
  });
}

export function useDeleteCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => categoriesService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<PaginatedResponse<Category>>(
        { queryKey: categoriesKeys.lists() },
        (old) =>
          old
            ? {
                ...old,
                data: old.data.filter((c) => c.id !== id),
                totalRecords: Math.max(0, old.totalRecords - 1),
              }
            : old
      );
      queryClient.invalidateQueries({ queryKey: categoriesKeys.lists() });
    },
  });
}

import { apiClient } from "@/lib/api/client";
import type { LoginDto, LoginResponse, RegisterDto } from "./types";

export const authService = {
  login: async (dto: LoginDto): Promise<LoginResponse> => {
    const { data } = await apiClient.post<LoginResponse>(
      "/api/Auth/login",
      dto
    );
    return data;
  },

  register: async (dto: RegisterDto): Promise<string> => {
    const { data } = await apiClient.post<string>("/api/Auth/register", dto);
    return data;
  },
};

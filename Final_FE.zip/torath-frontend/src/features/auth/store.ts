import { create } from "zustand";
import { getToken, setToken, clearToken } from "@/lib/auth/token";
import { decodeSession, type Session } from "@/lib/auth/jwt";
import { queryClient } from "@/lib/queryClient";

type AuthState = {
  token: string | null;
  session: Session | null;
  isAuthenticated: boolean;
  isHydrated: boolean;
  login: (token: string) => void;
  logout: () => void;
  hydrate: () => void;
};

function buildState(token: string | null) {
  if (!token) return { token: null, session: null, isAuthenticated: false };
  const session = decodeSession(token);
  if (!session || session.isExpired) {
    clearToken();
    return { token: null, session: null, isAuthenticated: false };
  }
  return { token, session, isAuthenticated: true };
}

export const useAuthStore = create<AuthState>((set) => ({
  ...buildState(null),
  isHydrated: false,

  login: (token) => {
    setToken(token);
    // A different user may now be signing in — clear anything cached
    // under the previous session (ownership checks, admin analytics,
    // etc.) so nothing from the last account can flash on screen before
    // the new user's own data loads.
    queryClient.clear();
    set({ ...buildState(token), isHydrated: true });
  },

  logout: () => {
    clearToken();
    queryClient.clear();
    set({ token: null, session: null, isAuthenticated: false, isHydrated: true });
  },

  // Called once on app boot to restore session from localStorage. Until
  // this runs, isAuthenticated defaults to false even if a valid token
  // exists — RequireAuth/RequireRole must wait for isHydrated before
  // trusting isAuthenticated, or a hard page reload (e.g. returning from
  // an external redirect like Stripe Checkout) races the redirect-to-
  // login check against this and loses the session on every refresh.
  hydrate: () => {
    set({ ...buildState(getToken()), isHydrated: true });
  },
}));

// Fired by lib/api/client.ts on any 401 response — keeps the API layer
// decoupled from the auth store (see client.ts comment).
window.addEventListener("torath:session-expired", () => {
  useAuthStore.getState().logout();
});

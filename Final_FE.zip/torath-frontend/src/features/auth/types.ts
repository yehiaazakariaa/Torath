export type LoginDto = {
  email: string;
  password: string;
};

export type RegisterDto = {
  fullName: string;
  email: string;
  password: string;
};

export type LoginResponse = {
  token: string;
  message: string;
};

/**
 * Confirmed against DTOs/AnalyticsDtos.cs + AnalyticsService.cs
 * (GET /api/admin/analytics, Admin-only).
 *
 * `type` values match the ContentType convention used elsewhere in the
 * API: "Book", "Magazine", "Newspaper", "Article", "Research Paper"
 * (with a space) — not the frontend's ContentType union directly, so
 * routing maps it explicitly rather than casting.
 *
 * Both `topViewed` and `topRated` are independently queried per entity
 * (top 10 by ViewCount / top 10 by Rating respectively), pooled, and
 * re-sorted — each is a true top-10 across the whole catalog for its
 * own metric, not derived from the other.
 */
export type AnalyticsItem = {
  id: number;
  title: string;
  type: string;
  viewCount: number;
  rating: number;
};

export type AnalyticsDashboard = {
  totalViews: number;
  totalItems: number;
  topViewed: AnalyticsItem[];
  topRated: AnalyticsItem[];
};

import { apiClient } from "@/lib/api/client";

export const searchIndexService = {
  rebuildAll: () => apiClient.post("/api/admin/search-index/rebuild"),
  rebuildBooks: () => apiClient.post("/api/admin/search-index/rebuild/books"),
  rebuildArticles: () =>
    apiClient.post("/api/admin/search-index/rebuild/articles"),
  rebuildResearchPapers: () =>
    apiClient.post("/api/admin/search-index/rebuild/research-papers"),
  rebuildMagazines: () =>
    apiClient.post("/api/admin/search-index/rebuild/magazines"),
  rebuildNewspapers: () =>
    apiClient.post("/api/admin/search-index/rebuild/newspapers"),
};

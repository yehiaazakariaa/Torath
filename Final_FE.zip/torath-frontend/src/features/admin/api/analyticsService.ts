import { apiClient } from "@/lib/api/client";
import type { AnalyticsDashboard } from "../types";

export const analyticsService = {
  getDashboard: async (): Promise<AnalyticsDashboard> => {
    const { data } = await apiClient.get<AnalyticsDashboard>(
      "/api/admin/analytics"
    );
    return data;
  },
};

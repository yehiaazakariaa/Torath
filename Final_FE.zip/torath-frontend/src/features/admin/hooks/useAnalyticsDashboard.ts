import { useQuery } from "@tanstack/react-query";
import { analyticsService } from "../api/analyticsService";

export function useAnalyticsDashboard() {
  return useQuery({
    queryKey: ["admin", "analytics"],
    queryFn: analyticsService.getDashboard,
    staleTime: 60_000,
  });
}

import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { searchIndexService } from "../api/searchIndexService";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toApiError } from "@/lib/api/errors";

const TRIGGERS: {
  id: keyof typeof searchIndexService;
  label: string;
  description: string;
}[] = [
  {
    id: "rebuildAll",
    label: "Rebuild everything",
    description: "Re-indexes all content types from SQL Server into Elasticsearch.",
  },
  { id: "rebuildBooks", label: "Rebuild books", description: "Books only." },
  {
    id: "rebuildArticles",
    label: "Rebuild articles",
    description: "Magazine and newspaper articles only.",
  },
  {
    id: "rebuildResearchPapers",
    label: "Rebuild research papers",
    description: "Research papers only.",
  },
  {
    id: "rebuildMagazines",
    label: "Rebuild magazines",
    description: "Magazines only.",
  },
  {
    id: "rebuildNewspapers",
    label: "Rebuild newspapers",
    description: "Newspapers only.",
  },
];

export function AdminSearchIndexPage() {
  return (
    <div>
      <h1 className="font-display text-3xl">Search index</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Rebuild the Elasticsearch index from the current SQL Server data.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {TRIGGERS.map((trigger) => (
          <RebuildCard key={trigger.id} {...trigger} />
        ))}
      </div>
    </div>
  );
}

function RebuildCard({
  id,
  label,
  description,
}: {
  id: keyof typeof searchIndexService;
  label: string;
  description: string;
}) {
  const mutation = useMutation({
    mutationFn: () => searchIndexService[id](),
    onSuccess: () => toast.success(`${label} — done`),
    onError: (error) => toast.error(toApiError(error).message),
  });

  return (
    <Card className="p-5">
      <p className="font-medium">{label}</p>
      <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      <Button
        variant="secondary"
        size="sm"
        className="mt-4"
        onClick={() => mutation.mutate()}
        disabled={mutation.isPending}
      >
        {mutation.isPending ? "Rebuilding…" : "Rebuild"}
      </Button>
    </Card>
  );
}

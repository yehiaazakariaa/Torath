import { Link } from "react-router-dom";
import {
  BookOpen,
  Newspaper as NewspaperIcon,
  FileText,
  GraduationCap,
  Tags,
  RefreshCw,
  BarChart3,
} from "lucide-react";
import { useBooks } from "@/features/books/hooks/useBooks";
import { useMagazines } from "@/features/magazines/hooks/useMagazines";
import { useNewspapers } from "@/features/newspapers/hooks/useNewspapers";
import { useArticles } from "@/features/articles/hooks/useArticles";
import { useResearchPapers } from "@/features/research-papers/hooks/useResearchPapers";
import { Card } from "@/components/ui/card";

/**
 * No dashboard-stats endpoint exists on the backend — counts here are
 * derived by requesting page 1 with pageSize 1 from each list endpoint
 * and reading `totalRecords`. Cheap enough for five calls on page load;
 * should be replaced with a dedicated stats endpoint if that ever exists.
 */
export function AdminDashboardPage() {
  const books = useBooks({ page: 1, pageSize: 1 });
  const magazines = useMagazines({ page: 1, pageSize: 1 });
  const newspapers = useNewspapers({ page: 1, pageSize: 1 });
  const articles = useArticles({ page: 1, pageSize: 1 });
  const papers = useResearchPapers({ page: 1, pageSize: 1 });

  const stats = [
    { label: "Books", count: books.data?.totalRecords, href: "/admin/books", icon: BookOpen },
    { label: "Magazines", count: magazines.data?.totalRecords, href: "/admin/magazines", icon: BookOpen },
    { label: "Newspapers", count: newspapers.data?.totalRecords, href: "/admin/newspapers", icon: NewspaperIcon },
    { label: "Articles", count: articles.data?.totalRecords, href: "/admin/articles", icon: FileText },
    { label: "Research Papers", count: papers.data?.totalRecords, href: "/admin/research-papers", icon: GraduationCap },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl">Dashboard</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        An overview of everything in the catalog.
      </p>

      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {stats.map((stat) => (
          <Link key={stat.label} to={stat.href}>
            <Card className="p-5 transition-shadow hover:shadow-[0_8px_24px_-8px_hsl(var(--accent)/0.35)]">
              <stat.icon className="h-5 w-5 text-accent" />
              <p className="mt-3 font-display text-2xl">
                {stat.count ?? "—"}
              </p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </Card>
          </Link>
        ))}
      </div>

      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        <Link to="/admin/analytics">
          <Card className="flex items-center gap-3 p-5 transition-colors hover:bg-muted">
            <BarChart3 className="h-5 w-5 text-accent" />
            <div>
              <p className="font-medium">Analytics</p>
              <p className="text-sm text-muted-foreground">
                Views, ratings, and most popular content
              </p>
            </div>
          </Card>
        </Link>
        <Link to="/admin/categories">
          <Card className="flex items-center gap-3 p-5 transition-colors hover:bg-muted">
            <Tags className="h-5 w-5 text-accent" />
            <div>
              <p className="font-medium">Manage Categories</p>
              <p className="text-sm text-muted-foreground">
                Organize the classification used across all content types
              </p>
            </div>
          </Card>
        </Link>
        <Link to="/admin/search-index">
          <Card className="flex items-center gap-3 p-5 transition-colors hover:bg-muted">
            <RefreshCw className="h-5 w-5 text-accent" />
            <div>
              <p className="font-medium">Search Index</p>
              <p className="text-sm text-muted-foreground">
                Rebuild the Elasticsearch index after bulk changes
              </p>
            </div>
          </Card>
        </Link>
      </div>
    </div>
  );
}

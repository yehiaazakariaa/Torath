import { Link } from "react-router-dom";
import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import {
  useNewspapers,
  useCreateNewspaper,
  useUpdateNewspaper,
  useDeleteNewspaper,
} from "@/features/newspapers/hooks/useNewspapers";
import { useCategories } from "@/features/categories/hooks/useCategories";
import type { Newspaper, NewspaperWriteDto } from "@/features/newspapers/types";
import { Button } from "@/components/ui/button";
import { AdminTable } from "@/components/shared/AdminTable";
import { FormModal } from "@/components/shared/FormModal";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { PdfUploadField } from "@/components/shared/PdfUploadField";
import { ImageUploadField } from "@/components/shared/ImageUploadField";
import { Pagination } from "@/components/shared/Pagination";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { toApiError } from "@/lib/api/errors";

const newspaperSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional().or(z.literal("")),
  language: z.string().optional().or(z.literal("")),
  publicationDate: z.string().min(1, "Publication date is required"),
  publisher: z.string().optional().or(z.literal("")),
  categoryId: z.coerce.number().min(1, "Category is required"),
  frequency: z.string().optional().or(z.literal("")),
  price: z.coerce.number().min(0),
  pdfFilePath: z.string().nullable().optional(),
  coverImageUrl: z.string().nullable().optional(),
});

type NewspaperFormValues = z.infer<typeof newspaperSchema>;

export function AdminNewspapersPage() {
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Newspaper | null>(null);
  const [deleting, setDeleting] = useState<Newspaper | null>(null);

  const { data, isLoading } = useNewspapers({ page, pageSize: 10 });
  const { data: categories } = useCategories({ pageSize: 100 });
  const createNewspaper = useCreateNewspaper();
  const updateNewspaper = useUpdateNewspaper(editing?.id ?? -1);
  const deleteNewspaper = useDeleteNewspaper();

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<NewspaperFormValues>({ resolver: zodResolver(newspaperSchema) });

  const openCreate = () => {
    setEditing(null);
    reset({
      title: "",
      description: "",
      language: "",
      publicationDate: "",
      publisher: "",
      categoryId: undefined as unknown as number,
      frequency: "",
      price: 0,
      pdfFilePath: null,
      coverImageUrl: null,
    });
    setFormOpen(true);
  };

  const openEdit = (newspaper: Newspaper) => {
    setEditing(newspaper);
    reset({
      title: newspaper.title ?? "",
      description: newspaper.description ?? "",
      language: newspaper.language ?? "",
      publicationDate: newspaper.publicationDate?.slice(0, 10),
      publisher: newspaper.publisher ?? "",
      categoryId: newspaper.categoryId,
      frequency: newspaper.frequency ?? "",
      price: newspaper.price,
      pdfFilePath: newspaper.pdfFilePath,
      coverImageUrl: newspaper.coverImageUrl,
    });
    setFormOpen(true);
  };

  const onSubmit = (values: NewspaperFormValues) => {
    const dto: NewspaperWriteDto = {
      ...values,
      description: values.description || null,
      language: values.language || null,
      publisher: values.publisher || null,
      frequency: values.frequency || null,
      publicationDate: new Date(values.publicationDate).toISOString(),
    };
    const onSuccess = () => {
      toast.success(editing ? "Newspaper updated" : "Newspaper created");
      setFormOpen(false);
    };
    const onError = (error: unknown) => toast.error(toApiError(error).message);

    if (editing) {
      updateNewspaper.mutate(dto, { onSuccess, onError });
    } else {
      createNewspaper.mutate(dto, { onSuccess, onError });
    }
  };

  const handleDelete = () => {
    if (!deleting) return;
    deleteNewspaper.mutate(deleting.id, {
      onSuccess: () => {
        toast.success("Newspaper deleted");
        setDeleting(null);
      },
      onError: (error) => toast.error(toApiError(error).message),
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl">Manage Newspapers</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {data?.totalRecords ?? 0} newspapers
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add newspaper
        </Button>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <>
            <AdminTable
              rows={data?.data ?? []}
              onEdit={openEdit}
              onDelete={setDeleting}
              columns={[
                {
                  header: "Title",
                  cell: (n) =>
                    n.title ? (
                      <Link
                        to={`/newspapers/${n.id}`}
                        className="text-info hover:underline"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {n.title}
                      </Link>
                    ) : (
                      "—"
                    ),
                },
                { header: "Publisher", cell: (n) => n.publisher ?? "—" },
                { header: "Category", cell: (n) => n.categoryName || "—" },
                { header: "Frequency", cell: (n) => n.frequency ?? "—" },
                { header: "Price", cell: (n) => `$${n.price.toFixed(2)}` },
                {
                  header: "Rating / Views",
                  cell: (n) => <RatingBadge rating={n.rating} viewCount={n.viewCount} />,
                },
                {
                  header: "Issues",
                  cell: (n) => (
                    <Link
                      to={`/admin/newspapers/${n.id}/issues`}
                      className="text-info hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      Manage issues
                    </Link>
                  ),
                },
              ]}
            />
            {data && (
              <Pagination
                page={data.pageNumber}
                pageSize={data.pageSize}
                totalCount={data.totalRecords}
                onPageChange={setPage}
              />
            )}
          </>
        )}
      </div>

      <FormModal
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit newspaper" : "Add newspaper"}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Title</label>
            <input className="input mt-1" {...register("title")} />
            {errors.title && (
              <p className="mt-1 text-xs text-destructive">{errors.title.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium">Description</label>
            <textarea className="input mt-1" rows={3} {...register("description")} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium">Publisher</label>
              <input className="input mt-1" {...register("publisher")} />
            </div>
            <div>
              <label className="text-sm font-medium">Language</label>
              <input className="input mt-1" {...register("language")} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium">Frequency</label>
              <input
                className="input mt-1"
                placeholder="Daily, Weekly…"
                {...register("frequency")}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Price</label>
              <input type="number" step="0.01" className="input mt-1" {...register("price")} />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Publication date</label>
            <input type="date" className="input mt-1" {...register("publicationDate")} />
            {errors.publicationDate && (
              <p className="mt-1 text-xs text-destructive">
                {errors.publicationDate.message}
              </p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium">Category</label>
            <select className="input mt-1" {...register("categoryId")}>
              <option value="">Select a category</option>
              {(categories?.data ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            {errors.categoryId && (
              <p className="mt-1 text-xs text-destructive">
                {errors.categoryId.message}
              </p>
            )}
          </div>

          <Controller
            control={control}
            name="coverImageUrl"
            render={({ field }) => (
              <ImageUploadField
                label="Cover image"
                value={field.value}
                onChange={field.onChange}
                aspect={16 / 10}
              />
            )}
          />
          <Controller
            control={control}
            name="pdfFilePath"
            render={({ field }) => (
              <PdfUploadField
                label="PDF file"
                value={field.value}
                onChange={field.onChange}
              />
            )}
          />

          <Button
            type="submit"
            className="w-full"
            disabled={createNewspaper.isPending || updateNewspaper.isPending}
          >
            {createNewspaper.isPending || updateNewspaper.isPending
              ? "Saving…"
              : "Save newspaper"}
          </Button>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(open) => !open && setDeleting(null)}
        title="Delete newspaper"
        description={`This will permanently remove "${deleting?.title}" and is not reversible.`}
        onConfirm={handleDelete}
        isPending={deleteNewspaper.isPending}
      />
    </div>
  );
}

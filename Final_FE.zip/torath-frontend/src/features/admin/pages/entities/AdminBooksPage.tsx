import { useState } from "react";
import { Link } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import {
  useBooks,
  useCreateBook,
  useUpdateBook,
  useDeleteBook,
} from "@/features/books/hooks/useBooks";
import { useCategories } from "@/features/categories/hooks/useCategories";
import type { Book, BookWriteDto } from "@/features/books/types";
import { Button } from "@/components/ui/button";
import { AdminTable } from "@/components/shared/AdminTable";
import { FormModal } from "@/components/shared/FormModal";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { ImageUploadField } from "@/components/shared/ImageUploadField";
import { PdfUploadField } from "@/components/shared/PdfUploadField";
import { Pagination } from "@/components/shared/Pagination";
import { RatingBadge, SortControl, applySort, type SortOption } from "@/components/shared/RatingBadge";
import { toApiError } from "@/lib/api/errors";

const bookSchema = z.object({
  title: z.string().min(1, "Title is required").max(200),
  description: z.string().max(1000).optional().or(z.literal("")),
  language: z.string().min(1, "Language is required").max(50),
  publicationDate: z.string().min(1, "Publication date is required"),
  publisher: z.string().max(200).optional().or(z.literal("")),
  categoryId: z.coerce.number().min(1, "Category is required"),
  isbn: z.string().min(1, "ISBN is required").max(20),
  authors: z.string().min(1, "Authors are required").max(200),
  numberOfPages: z.coerce.number().min(0),
  edition: z.string().max(50).optional().or(z.literal("")),
  coverImageUrl: z.string().nullable().optional(),
  pdfFileUrl: z.string().nullable().optional(),
});

type BookFormValues = z.infer<typeof bookSchema>;

export function AdminBooksPage() {
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<SortOption>("default");
  const [formOpen, setFormOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [deletingBook, setDeletingBook] = useState<Book | null>(null);

  const { data, isLoading } = useBooks({ page, pageSize: 10 });
  const { data: categories } = useCategories({ pageSize: 100 });
  const createBook = useCreateBook();
  const updateBook = useUpdateBook(editingBook?.id ?? -1);
  const deleteBook = useDeleteBook();

  const sortedRows = applySort(data?.data ?? [], sort);

  const openCreate = () => {
    setEditingBook(null);
    setFormOpen(true);
  };

  const openEdit = (book: Book) => {
    setEditingBook(book);
    setFormOpen(true);
  };

  const handleDelete = () => {
    if (!deletingBook) return;
    deleteBook.mutate(deletingBook.id, {
      onSuccess: () => {
        toast.success("Book deleted");
        setDeletingBook(null);
      },
      onError: (error) => toast.error(toApiError(error).message),
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl">Manage Books</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {data?.totalRecords ?? 0} books in the catalog
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add book
        </Button>
      </div>

      <div className="mt-4">
        <SortControl value={sort} onChange={setSort} />
      </div>

      <div className="mt-4">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <>
            <AdminTable
              rows={sortedRows}
              onEdit={openEdit}
              onDelete={setDeletingBook}
              columns={[
                {
                  header: "Title",
                  cell: (b) => (
                    <Link
                      to={`/books/${b.id}`}
                      className="text-info hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {b.title}
                    </Link>
                  ),
                },
                { header: "Category", cell: (b) => b.categoryName || "—" },
                { header: "Language", cell: (b) => b.language },
                {
                  header: "Rating / Views",
                  cell: (b) => <RatingBadge rating={b.rating} viewCount={b.viewCount} />,
                },
              ]}
            />
            {data && (
              <Pagination
                page={data.pageNumber}
                pageSize={data.pageSize}
                totalCount={data.totalRecords}
                onPageChange={setPage}
              />
            )}
          </>
        )}
      </div>

      <FormModal
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editingBook ? "Edit book" : "Add book"}
      >
        <BookForm
          key={editingBook?.id ?? "new"}
          initial={editingBook}
          categories={categories?.data ?? []}
          isSaving={createBook.isPending || updateBook.isPending}
          onSubmit={(values) => {
            const dto: BookWriteDto = {
              ...values,
              description: values.description || null,
              publisher: values.publisher || null,
              edition: values.edition || null,
              publicationDate: new Date(values.publicationDate).toISOString(),
            };

            const onSuccess = () => {
              toast.success(editingBook ? "Book updated" : "Book created");
              setFormOpen(false);
            };
            const onError = (error: unknown) =>
              toast.error(toApiError(error).message);

            if (editingBook) {
              updateBook.mutate(dto, { onSuccess, onError });
            } else {
              createBook.mutate(dto, { onSuccess, onError });
            }
          }}
        />
      </FormModal>

      <ConfirmDialog
        open={!!deletingBook}
        onOpenChange={(open) => !open && setDeletingBook(null)}
        title="Delete book"
        description={`This will permanently remove "${deletingBook?.title}" from the catalog.`}
        onConfirm={handleDelete}
        isPending={deleteBook.isPending}
      />
    </div>
  );
}

function BookForm({
  initial,
  categories,
  isSaving,
  onSubmit,
}: {
  initial: Book | null;
  categories: { id: number; name: string }[];
  isSaving: boolean;
  onSubmit: (values: BookFormValues) => void;
}) {
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<BookFormValues>({
    resolver: zodResolver(bookSchema),
    defaultValues: initial
      ? {
          title: initial.title,
          description: initial.description ?? "",
          language: initial.language,
          // API only returns publicationYear, not the exact day/month —
          // default to Jan 1 of the known year (see types.ts note).
          publicationDate: `${initial.publicationYear}-01-01`,
          publisher: initial.publisher ?? "",
          categoryId: initial.categoryId,
          isbn: initial.isbn,
          authors: initial.authors,
          numberOfPages: initial.numberOfPages,
          edition: initial.edition ?? "",
          coverImageUrl: initial.coverImageUrl,
          pdfFileUrl: initial.pdfFileUrl,
        }
      : {
          title: "",
          description: "",
          language: "",
          publicationDate: "",
          publisher: "",
          categoryId: undefined as unknown as number,
          isbn: "",
          authors: "",
          numberOfPages: 0,
          edition: "",
          coverImageUrl: null,
          pdfFileUrl: null,
        },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Field label="Title" error={errors.title?.message}>
        <input className="input" {...register("title")} />
      </Field>
      <Field label="Authors" error={errors.authors?.message}>
        <input className="input" {...register("authors")} />
      </Field>
      <Field label="Description" error={errors.description?.message}>
        <textarea className="input" rows={3} {...register("description")} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="ISBN" error={errors.isbn?.message}>
          <input className="input" {...register("isbn")} />
        </Field>
        <Field label="Language" error={errors.language?.message}>
          <input className="input" {...register("language")} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Publisher" error={errors.publisher?.message}>
          <input className="input" {...register("publisher")} />
        </Field>
        <Field label="Edition" error={errors.edition?.message}>
          <input className="input" {...register("edition")} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Pages" error={errors.numberOfPages?.message}>
          <input type="number" className="input" {...register("numberOfPages")} />
        </Field>
        <Field label="Publication date" error={errors.publicationDate?.message}>
          <input type="date" className="input" {...register("publicationDate")} />
        </Field>
      </div>
      <Field label="Category" error={errors.categoryId?.message}>
        <select className="input" {...register("categoryId")}>
          <option value="">Select a category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </Field>

      <Controller
        control={control}
        name="coverImageUrl"
        render={({ field }) => (
          <ImageUploadField
            label="Cover image"
            value={field.value}
            onChange={field.onChange}
          />
        )}
      />
      <Controller
        control={control}
        name="pdfFileUrl"
        render={({ field }) => (
          <PdfUploadField
            label="PDF file"
            value={field.value}
            onChange={field.onChange}
          />
        )}
      />

      <Button type="submit" className="w-full" disabled={isSaving}>
        {isSaving ? "Saving…" : "Save book"}
      </Button>
    </form>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="text-sm font-medium">{label}</label>
      <div className="mt-1">{children}</div>
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

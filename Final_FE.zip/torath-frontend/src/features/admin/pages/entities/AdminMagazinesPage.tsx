import { Link } from "react-router-dom";
import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import {
  useMagazines,
  useCreateMagazine,
  useUpdateMagazine,
  useDeleteMagazine,
} from "@/features/magazines/hooks/useMagazines";
import { useCategories } from "@/features/categories/hooks/useCategories";
import type { Magazine, MagazineWriteDto } from "@/features/magazines/types";
import { Button } from "@/components/ui/button";
import { AdminTable } from "@/components/shared/AdminTable";
import { FormModal } from "@/components/shared/FormModal";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { ImageUploadField } from "@/components/shared/ImageUploadField";
import { PdfUploadField } from "@/components/shared/PdfUploadField";
import { Pagination } from "@/components/shared/Pagination";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { toApiError } from "@/lib/api/errors";

const magazineSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional().or(z.literal("")),
  language: z.string().optional().or(z.literal("")),
  publicationDate: z.string().min(1, "Publication date is required"),
  publisher: z.string().optional().or(z.literal("")),
  categoryId: z.coerce.number().min(1, "Category is required"),
  issn: z.string().optional().or(z.literal("")),
  coverImageUrl: z.string().nullable().optional(),
  pdfFileUrl: z.string().nullable().optional(),
});

type MagazineFormValues = z.infer<typeof magazineSchema>;

export function AdminMagazinesPage() {
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Magazine | null>(null);
  const [deleting, setDeleting] = useState<Magazine | null>(null);

  const { data, isLoading } = useMagazines({ page, pageSize: 10 });
  const { data: categories } = useCategories({ pageSize: 100 });
  const createMagazine = useCreateMagazine();
  const updateMagazine = useUpdateMagazine(editing?.id ?? -1);
  const deleteMagazine = useDeleteMagazine();

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<MagazineFormValues>({ resolver: zodResolver(magazineSchema) });

  const openCreate = () => {
    setEditing(null);
    reset({
      title: "",
      description: "",
      language: "",
      publicationDate: "",
      publisher: "",
      categoryId: undefined as unknown as number,
      issn: "",
      coverImageUrl: null,
      pdfFileUrl: null,
    });
    setFormOpen(true);
  };

  const openEdit = (magazine: Magazine) => {
    setEditing(magazine);
    reset({
      title: magazine.title ?? "",
      description: magazine.description ?? "",
      language: magazine.language ?? "",
      publicationDate: magazine.publicationDate?.slice(0, 10),
      publisher: magazine.publisher ?? "",
      categoryId: magazine.categoryId,
      issn: magazine.issn ?? "",
      coverImageUrl: magazine.coverImageUrl,
      pdfFileUrl: magazine.pdfFileUrl,
    });
    setFormOpen(true);
  };

  const onSubmit = (values: MagazineFormValues) => {
    const dto: MagazineWriteDto = {
      ...values,
      description: values.description || null,
      language: values.language || null,
      publisher: values.publisher || null,
      issn: values.issn || null,
      publicationDate: new Date(values.publicationDate).toISOString(),
    };
    const onSuccess = () => {
      toast.success(editing ? "Magazine updated" : "Magazine created");
      setFormOpen(false);
    };
    const onError = (error: unknown) => toast.error(toApiError(error).message);

    if (editing) {
      updateMagazine.mutate(dto, { onSuccess, onError });
    } else {
      createMagazine.mutate(dto, { onSuccess, onError });
    }
  };

  const handleDelete = () => {
    if (!deleting) return;
    deleteMagazine.mutate(deleting.id, {
      onSuccess: () => {
        toast.success("Magazine deleted");
        setDeleting(null);
      },
      onError: (error) => toast.error(toApiError(error).message),
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl">Manage Magazines</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {data?.totalRecords ?? 0} magazines
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add magazine
        </Button>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <>
            <AdminTable
              rows={data?.data ?? []}
              onEdit={openEdit}
              onDelete={setDeleting}
              columns={[
                {
                  header: "Title",
                  cell: (m) =>
                    m.title ? (
                      <Link
                        to={`/magazines/${m.id}`}
                        className="text-info hover:underline"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {m.title}
                      </Link>
                    ) : (
                      "—"
                    ),
                },
                { header: "Publisher", cell: (m) => m.publisher ?? "—" },
                { header: "ISSN", cell: (m) => m.issn ?? "—" },
                {
                  header: "Category",
                  cell: (m) => m.categoryName || `#${m.categoryId}`,
                },
                {
                  header: "Rating / Views",
                  cell: (m) => <RatingBadge rating={m.rating} viewCount={m.viewCount} />,
                },
                {
                  header: "Issues",
                  cell: (m) => (
                    <Link
                      to={`/admin/magazines/${m.id}/issues`}
                      className="text-info hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      Manage issues
                    </Link>
                  ),
                },
              ]}
            />
            {data && (
              <Pagination
                page={data.pageNumber}
                pageSize={data.pageSize}
                totalCount={data.totalRecords}
                onPageChange={setPage}
              />
            )}
          </>
        )}
      </div>

      <FormModal
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit magazine" : "Add magazine"}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Title</label>
            <input className="input mt-1" {...register("title")} />
            {errors.title && (
              <p className="mt-1 text-xs text-destructive">{errors.title.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium">Description</label>
            <textarea className="input mt-1" rows={3} {...register("description")} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium">Publisher</label>
              <input className="input mt-1" {...register("publisher")} />
            </div>
            <div>
              <label className="text-sm font-medium">Language</label>
              <input className="input mt-1" {...register("language")} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium">ISSN</label>
              <input className="input mt-1" {...register("issn")} />
            </div>
            <div>
              <label className="text-sm font-medium">Publication date</label>
              <input type="date" className="input mt-1" {...register("publicationDate")} />
              {errors.publicationDate && (
                <p className="mt-1 text-xs text-destructive">
                  {errors.publicationDate.message}
                </p>
              )}
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Category</label>
            <select className="input mt-1" {...register("categoryId")}>
              <option value="">Select a category</option>
              {(categories?.data ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            {errors.categoryId && (
              <p className="mt-1 text-xs text-destructive">
                {errors.categoryId.message}
              </p>
            )}
          </div>
          <Controller
            control={control}
            name="coverImageUrl"
            render={({ field }) => (
              <ImageUploadField
                label="Cover image"
                value={field.value}
                onChange={field.onChange}
                aspect={16 / 10}
              />
            )}
          />
          <Controller
            control={control}
            name="pdfFileUrl"
            render={({ field }) => (
              <PdfUploadField
                label="PDF file"
                value={field.value}
                onChange={field.onChange}
              />
            )}
          />
          <Button
            type="submit"
            className="w-full"
            disabled={createMagazine.isPending || updateMagazine.isPending}
          >
            {createMagazine.isPending || updateMagazine.isPending
              ? "Saving…"
              : "Save magazine"}
          </Button>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(open) => !open && setDeleting(null)}
        title="Delete magazine"
        description={`This will permanently remove "${deleting?.title}" and is not reversible.`}
        onConfirm={handleDelete}
        isPending={deleteMagazine.isPending}
      />
    </div>
  );
}

import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { ArrowLeft, Plus } from "lucide-react";
import {
  useNewspaper,
  useNewspaperIssues,
  useCreateNewspaperIssue,
  useUpdateNewspaperIssue,
  useDeleteNewspaperIssue,
} from "@/features/newspapers/hooks/useNewspapers";
import type {
  NewspaperIssue,
  NewspaperIssueWriteDto,
} from "@/features/newspapers/types";
import { Button } from "@/components/ui/button";
import { AdminTable } from "@/components/shared/AdminTable";
import { FormModal } from "@/components/shared/FormModal";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { toApiError } from "@/lib/api/errors";

const issueSchema = z.object({
  issueNumber: z.string().optional().or(z.literal("")),
  publicationDate: z.string().min(1, "Publication date is required"),
});

type IssueFormValues = z.infer<typeof issueSchema>;

export function AdminNewspaperIssuesPage() {
  const { newspaperId: newspaperIdParam } = useParams<{ newspaperId: string }>();
  const newspaperId = Number(newspaperIdParam);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<NewspaperIssue | null>(null);
  const [deleting, setDeleting] = useState<NewspaperIssue | null>(null);

  const { data: newspaper } = useNewspaper(newspaperId);
  const { data: issues, isLoading } = useNewspaperIssues(newspaperId);
  const createIssue = useCreateNewspaperIssue();
  const updateIssue = useUpdateNewspaperIssue(editing?.id ?? -1, newspaperId);
  const deleteIssue = useDeleteNewspaperIssue(newspaperId);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<IssueFormValues>({ resolver: zodResolver(issueSchema) });

  const openCreate = () => {
    setEditing(null);
    reset({ issueNumber: "", publicationDate: "" });
    setFormOpen(true);
  };

  const openEdit = (issue: NewspaperIssue) => {
    setEditing(issue);
    reset({
      issueNumber: issue.issueNumber ?? "",
      publicationDate: issue.publicationDate?.slice(0, 10),
    });
    setFormOpen(true);
  };

  const onSubmit = (values: IssueFormValues) => {
    const dto: NewspaperIssueWriteDto = {
      issueNumber: values.issueNumber || null,
      publicationDate: new Date(values.publicationDate).toISOString(),
      newspaperId,
    };
    const onSuccess = () => {
      toast.success(editing ? "Issue updated" : "Issue created");
      setFormOpen(false);
    };
    const onError = (error: unknown) => toast.error(toApiError(error).message);

    if (editing) {
      updateIssue.mutate(dto, { onSuccess, onError });
    } else {
      createIssue.mutate(dto, { onSuccess, onError });
    }
  };

  const handleDelete = () => {
    if (!deleting) return;
    deleteIssue.mutate(deleting.id, {
      onSuccess: () => {
        toast.success("Issue deleted");
        setDeleting(null);
      },
      onError: (error) => toast.error(toApiError(error).message),
    });
  };

  return (
    <div>
      <Link
        to="/admin/newspapers"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Back to Newspapers
      </Link>

      <div className="mt-4 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl">
            Issues — {newspaper?.title ?? `Newspaper #${newspaperId}`}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {issues?.length ?? 0} issues
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add issue
        </Button>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <AdminTable
            rows={issues ?? []}
            onEdit={openEdit}
            onDelete={setDeleting}
            columns={[
              { header: "Issue #", cell: (i) => i.issueNumber ?? "—" },
              {
                header: "Published",
                cell: (i) => new Date(i.publicationDate).toLocaleDateString(),
              },
            ]}
          />
        )}
      </div>

      <FormModal
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit issue" : "Add issue"}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Issue number</label>
            <input className="input mt-1" {...register("issueNumber")} />
          </div>
          <div>
            <label className="text-sm font-medium">Publication date</label>
            <input type="date" className="input mt-1" {...register("publicationDate")} />
            {errors.publicationDate && (
              <p className="mt-1 text-xs text-destructive">
                {errors.publicationDate.message}
              </p>
            )}
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={createIssue.isPending || updateIssue.isPending}
          >
            {createIssue.isPending || updateIssue.isPending ? "Saving…" : "Save issue"}
          </Button>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(open) => !open && setDeleting(null)}
        title="Delete issue"
        description={`This will permanently remove issue "${deleting?.issueNumber}".`}
        onConfirm={handleDelete}
        isPending={deleteIssue.isPending}
      />
    </div>
  );
}

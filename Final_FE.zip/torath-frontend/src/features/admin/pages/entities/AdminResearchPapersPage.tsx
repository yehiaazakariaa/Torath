import { useState } from "react";
import { Link } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import {
  useResearchPapers,
  useCreateResearchPaper,
  useUpdateResearchPaper,
  useDeleteResearchPaper,
} from "@/features/research-papers/hooks/useResearchPapers";
import { useCategories } from "@/features/categories/hooks/useCategories";
import type {
  ResearchPaper,
  ResearchPaperWriteDto,
} from "@/features/research-papers/types";
import { Button } from "@/components/ui/button";
import { AdminTable } from "@/components/shared/AdminTable";
import { FormModal } from "@/components/shared/FormModal";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { ImageUploadField } from "@/components/shared/ImageUploadField";
import { PdfUploadField } from "@/components/shared/PdfUploadField";
import { Pagination } from "@/components/shared/Pagination";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { toApiError } from "@/lib/api/errors";

const paperSchema = z.object({
  title: z.string().min(1, "Title is required").max(200),
  abstract: z.string().optional().or(z.literal("")),
  author: z.string().min(1, "Author is required").max(200),
  publicationYear: z.coerce.number().min(1000).max(9999),
  categoryId: z.coerce.number().min(1, "Category is required"),
  coverImageUrl: z.string().nullable().optional(),
  pdfFileUrl: z.string().nullable().optional(),
});

type PaperFormValues = z.infer<typeof paperSchema>;

export function AdminResearchPapersPage() {
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<ResearchPaper | null>(null);
  const [deleting, setDeleting] = useState<ResearchPaper | null>(null);

  const { data, isLoading } = useResearchPapers({ page, pageSize: 10 });
  const { data: categories } = useCategories({ pageSize: 100 });
  const createPaper = useCreateResearchPaper();
  const updatePaper = useUpdateResearchPaper(editing?.id ?? -1);
  const deletePaper = useDeleteResearchPaper();

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<PaperFormValues>({ resolver: zodResolver(paperSchema) });

  const openCreate = () => {
    setEditing(null);
    reset({
      title: "",
      abstract: "",
      author: "",
      publicationYear: new Date().getFullYear(),
      categoryId: undefined as unknown as number,
      coverImageUrl: null,
      pdfFileUrl: null,
    });
    setFormOpen(true);
  };

  const openEdit = (paper: ResearchPaper) => {
    setEditing(paper);
    reset({
      title: paper.title,
      abstract: paper.abstract ?? "",
      author: paper.author,
      publicationYear: paper.publicationYear,
      categoryId: paper.categoryId,
      coverImageUrl: paper.coverImageUrl,
      pdfFileUrl: paper.pdfFileUrl,
    });
    setFormOpen(true);
  };

  const onSubmit = (values: PaperFormValues) => {
    const dto: ResearchPaperWriteDto = {
      ...values,
      abstract: values.abstract || null,
    };
    const onSuccess = () => {
      toast.success(editing ? "Research paper updated" : "Research paper created");
      setFormOpen(false);
    };
    const onError = (error: unknown) => toast.error(toApiError(error).message);

    if (editing) {
      updatePaper.mutate(dto, { onSuccess, onError });
    } else {
      createPaper.mutate(dto, { onSuccess, onError });
    }
  };

  const handleDelete = () => {
    if (!deleting) return;
    deletePaper.mutate(deleting.id, {
      onSuccess: () => {
        toast.success("Research paper deleted");
        setDeleting(null);
      },
      onError: (error) => toast.error(toApiError(error).message),
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl">Manage Research Papers</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {data?.totalRecords ?? 0} research papers
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add research paper
        </Button>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <>
            <AdminTable
              rows={data?.data ?? []}
              onEdit={openEdit}
              onDelete={setDeleting}
              columns={[
                {
                  header: "Title",
                  cell: (p) => (
                    <Link
                      to={`/research-papers/${p.id}`}
                      className="text-info hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {p.title}
                    </Link>
                  ),
                },
                { header: "Author", cell: (p) => p.author },
                { header: "Year", cell: (p) => p.publicationYear },
                { header: "Category", cell: (p) => p.categoryName },
                {
                  header: "Rating / Views",
                  cell: (p) => (
                    <span title="Backend doesn't populate these fields for Research Papers yet — always shows 0.">
                      <RatingBadge rating={p.rating} viewCount={p.viewCount} />
                    </span>
                  ),
                },
              ]}
            />
            {data && (
              <Pagination
                page={data.pageNumber}
                pageSize={data.pageSize}
                totalCount={data.totalRecords}
                onPageChange={setPage}
              />
            )}
          </>
        )}
      </div>

      <FormModal
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit research paper" : "Add research paper"}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Title</label>
            <input className="input mt-1" {...register("title")} />
            {errors.title && (
              <p className="mt-1 text-xs text-destructive">{errors.title.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium">Author</label>
            <input className="input mt-1" {...register("author")} />
            {errors.author && (
              <p className="mt-1 text-xs text-destructive">{errors.author.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium">Abstract</label>
            <textarea className="input mt-1" rows={4} {...register("abstract")} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium">Publication year</label>
              <input
                type="number"
                className="input mt-1"
                {...register("publicationYear")}
              />
              {errors.publicationYear && (
                <p className="mt-1 text-xs text-destructive">
                  {errors.publicationYear.message}
                </p>
              )}
            </div>
            <div>
              <label className="text-sm font-medium">Category</label>
              <select className="input mt-1" {...register("categoryId")}>
                <option value="">Select a category</option>
                {(categories?.data ?? []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              {errors.categoryId && (
                <p className="mt-1 text-xs text-destructive">
                  {errors.categoryId.message}
                </p>
              )}
            </div>
          </div>

          <Controller
            control={control}
            name="coverImageUrl"
            render={({ field }) => (
              <ImageUploadField
                label="Cover image"
                value={field.value}
                onChange={field.onChange}
              />
            )}
          />
          <Controller
            control={control}
            name="pdfFileUrl"
            render={({ field }) => (
              <PdfUploadField
                label="PDF file"
                value={field.value}
                onChange={field.onChange}
              />
            )}
          />

          <Button
            type="submit"
            className="w-full"
            disabled={createPaper.isPending || updatePaper.isPending}
          >
            {createPaper.isPending || updatePaper.isPending
              ? "Saving…"
              : "Save research paper"}
          </Button>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(open) => !open && setDeleting(null)}
        title="Delete research paper"
        description={`This will permanently remove "${deleting?.title}" and is not reversible.`}
        onConfirm={handleDelete}
        isPending={deletePaper.isPending}
      />
    </div>
  );
}

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import {
  useCategories,
  useCreateCategory,
  useUpdateCategory,
  useDeleteCategory,
} from "@/features/categories/hooks/useCategories";
import type { Category } from "@/features/categories/types";
import { Button } from "@/components/ui/button";
import { AdminTable } from "@/components/shared/AdminTable";
import { FormModal } from "@/components/shared/FormModal";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { toApiError } from "@/lib/api/errors";

const categorySchema = z.object({
  name: z.string().min(1, "Name is required").max(100),
  description: z.string().max(500).optional().or(z.literal("")),
});

type CategoryFormValues = z.infer<typeof categorySchema>;

export function AdminCategoriesPage() {
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [deleting, setDeleting] = useState<Category | null>(null);

  const { data, isLoading } = useCategories({ pageSize: 100 });
  const createCategory = useCreateCategory();
  const updateCategory = useUpdateCategory(editing?.id ?? -1);
  const deleteCategory = useDeleteCategory();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<CategoryFormValues>({ resolver: zodResolver(categorySchema) });

  const openCreate = () => {
    setEditing(null);
    reset({ name: "", description: "" });
    setFormOpen(true);
  };

  const openEdit = (category: Category) => {
    setEditing(category);
    reset({ name: category.name, description: category.description ?? "" });
    setFormOpen(true);
  };

  const onSubmit = (values: CategoryFormValues) => {
    const dto = { name: values.name, description: values.description || null };
    const onSuccess = () => {
      toast.success(editing ? "Category updated" : "Category created");
      setFormOpen(false);
    };
    const onError = (error: unknown) => toast.error(toApiError(error).message);

    if (editing) {
      updateCategory.mutate(dto, { onSuccess, onError });
    } else {
      createCategory.mutate(dto, { onSuccess, onError });
    }
  };

  const handleDelete = () => {
    if (!deleting) return;
    deleteCategory.mutate(deleting.id, {
      onSuccess: () => {
        toast.success("Category deleted");
        setDeleting(null);
      },
      onError: (error) => toast.error(toApiError(error).message),
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl">Manage Categories</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {data?.data.length ?? 0} categories
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add category
        </Button>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <AdminTable
            rows={data?.data ?? []}
            onEdit={openEdit}
            onDelete={setDeleting}
            columns={[
              { header: "Name", cell: (c) => c.name },
              { header: "Description", cell: (c) => c.description ?? "—" },
            ]}
          />
        )}
      </div>

      <FormModal
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit category" : "Add category"}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Name</label>
            <input className="input mt-1" {...register("name")} />
            {errors.name && (
              <p className="mt-1 text-xs text-destructive">{errors.name.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium">Description</label>
            <textarea className="input mt-1" rows={3} {...register("description")} />
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={createCategory.isPending || updateCategory.isPending}
          >
            {createCategory.isPending || updateCategory.isPending
              ? "Saving…"
              : "Save category"}
          </Button>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(open) => !open && setDeleting(null)}
        title="Delete category"
        description={`This will permanently remove "${deleting?.name}".`}
        onConfirm={handleDelete}
        isPending={deleteCategory.isPending}
      />
    </div>
  );
}

import { useState } from "react";
import { Link } from "react-router-dom";
import { useForm, Controller, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import {
  useArticles,
  useCreateArticle,
  useUpdateArticle,
  useDeleteArticle,
} from "@/features/articles/hooks/useArticles";
import { magazineIssuesService } from "@/features/magazines/api/magazinesService";
import { newspaperIssuesService } from "@/features/newspapers/api/newspapersService";
import type { Article, ArticleWriteDto } from "@/features/articles/types";
import { Button } from "@/components/ui/button";
import { AdminTable } from "@/components/shared/AdminTable";
import { FormModal } from "@/components/shared/FormModal";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { ImageUploadField } from "@/components/shared/ImageUploadField";
import { PdfUploadField } from "@/components/shared/PdfUploadField";
import { Pagination } from "@/components/shared/Pagination";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { toApiError } from "@/lib/api/errors";
import { useDebounce } from "@/hooks/useDebounce";

const articleSchema = z.object({
  title: z.string().min(1, "Title is required"),
  summary: z.string().optional().or(z.literal("")),
  content: z.string().optional().or(z.literal("")),
  author: z.string().optional().or(z.literal("")),
  pageNumber: z.coerce.number().min(0),
  keywords: z.string().optional().or(z.literal("")),
  coverImageUrl: z.string().nullable().optional(),
  pdfFileUrl: z.string().nullable().optional(),
  belongsTo: z.enum(["magazine", "newspaper"], {
    errorMap: () => ({ message: "Choose Magazine or Newspaper" }),
  }),
  issueId: z.coerce.number().min(1, "Enter a valid issue ID"),
});

type ArticleFormValues = z.infer<typeof articleSchema>;

import type { MagazineIssue } from "@/features/magazines/types";
import type { NewspaperIssue } from "@/features/newspapers/types";

/** Fires a GET for the entered issue ID so the admin can visually confirm
 * they're attaching the article to the right issue before saving. */
function useIssueLookup(belongsTo: "magazine" | "newspaper", issueId: number) {
  return useQuery<MagazineIssue | NewspaperIssue>({
    queryKey: ["issue-lookup", belongsTo, issueId],
    queryFn: async () =>
      belongsTo === "magazine"
        ? magazineIssuesService.getById(issueId)
        : newspaperIssuesService.getById(issueId),
    enabled: Number.isFinite(issueId) && issueId > 0,
    retry: false,
  });
}

function IssueConfirmation({
  belongsTo,
  issueId,
}: {
  belongsTo: "magazine" | "newspaper";
  issueId: number;
}) {
  const debouncedId = useDebounce(issueId, 400);
  const { data, isLoading, isError } = useIssueLookup(belongsTo, debouncedId);

  if (!debouncedId || !Number.isFinite(debouncedId) || debouncedId <= 0) return null;

  if (isLoading) {
    return (
      <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
        <Loader2 className="h-3.5 w-3.5 animate-spin" /> Checking issue…
      </p>
    );
  }

  if (isError || !data) {
    return (
      <p className="mt-1 flex items-center gap-1.5 text-xs text-destructive">
        <XCircle className="h-3.5 w-3.5" /> No {belongsTo} issue found with ID {debouncedId}
      </p>
    );
  }

  return (
    <p className="mt-1 flex items-center gap-1.5 text-xs text-accent">
      <CheckCircle2 className="h-3.5 w-3.5" />
      Issue {data.issueNumber ?? debouncedId}
      {"volumeNumber" in data && data.volumeNumber ? ` · Vol. ${data.volumeNumber}` : ""}
      {" — "}
      {new Date(data.publicationDate).toLocaleDateString()}
    </p>
  );
}

export function AdminArticlesPage() {
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Article | null>(null);
  const [deleting, setDeleting] = useState<Article | null>(null);

  const { data, isLoading } = useArticles({ page, pageSize: 10 });
  const createArticle = useCreateArticle();
  const updateArticle = useUpdateArticle(editing?.id ?? -1);
  const deleteArticle = useDeleteArticle();

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<ArticleFormValues>({ resolver: zodResolver(articleSchema) });

  const belongsTo = useWatch({ control, name: "belongsTo" });
  const issueId = useWatch({ control, name: "issueId" });

  const openCreate = () => {
    setEditing(null);
    reset({
      title: "",
      summary: "",
      content: "",
      author: "",
      pageNumber: 0,
      keywords: "",
      coverImageUrl: null,
      pdfFileUrl: null,
      belongsTo: "magazine",
      issueId: undefined as unknown as number,
    });
    setFormOpen(true);
  };

  const openEdit = (article: Article) => {
    setEditing(article);
    reset({
      title: article.title ?? "",
      summary: article.summary ?? "",
      content: article.content ?? "",
      author: article.author ?? "",
      pageNumber: article.pageNumber,
      keywords: article.keywords ?? "",
      coverImageUrl: article.coverImageUrl,
      pdfFileUrl: article.pdfFileUrl,
      belongsTo: article.magazineIssueId ? "magazine" : "newspaper",
      issueId: (article.magazineIssueId ?? article.newspaperIssueId) as number,
    });
    setFormOpen(true);
  };

  const onSubmit = (values: ArticleFormValues) => {
    const dto: ArticleWriteDto = {
      title: values.title,
      summary: values.summary || null,
      content: values.content || null,
      author: values.author || null,
      pageNumber: values.pageNumber,
      keywords: values.keywords || null,
      coverImageUrl: values.coverImageUrl,
      pdfFileUrl: values.pdfFileUrl,
      magazineIssueId: values.belongsTo === "magazine" ? values.issueId : null,
      newspaperIssueId: values.belongsTo === "newspaper" ? values.issueId : null,
    };
    const onSuccess = () => {
      toast.success(editing ? "Article updated" : "Article created");
      setFormOpen(false);
    };
    const onError = (error: unknown) => toast.error(toApiError(error).message);

    if (editing) {
      updateArticle.mutate(dto, { onSuccess, onError });
    } else {
      createArticle.mutate(dto, { onSuccess, onError });
    }
  };

  const handleDelete = () => {
    if (!deleting) return;
    deleteArticle.mutate(deleting.id, {
      onSuccess: () => {
        toast.success("Article deleted");
        setDeleting(null);
      },
      onError: (error) => toast.error(toApiError(error).message),
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl">Manage Articles</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {data?.totalRecords ?? 0} articles
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Add article
        </Button>
      </div>

      <div className="mt-6">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (
          <>
            <AdminTable
              rows={data?.data ?? []}
              onEdit={openEdit}
              onDelete={setDeleting}
              columns={[
                {
                  header: "Title",
                  cell: (a) =>
                    a.title ? (
                      <Link
                        to={`/articles/${a.id}`}
                        className="text-info hover:underline"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {a.title}
                      </Link>
                    ) : (
                      "—"
                    ),
                },
                { header: "Author", cell: (a) => a.author ?? "—" },
                {
                  header: "Belongs to",
                  cell: (a) =>
                    a.magazineIssueId
                      ? `Magazine issue #${a.magazineIssueId}`
                      : a.newspaperIssueId
                        ? `Newspaper issue #${a.newspaperIssueId}`
                        : "—",
                },
                {
                  header: "Rating / Views",
                  cell: (a) => <RatingBadge rating={a.rating} viewCount={a.viewCount} />,
                },
              ]}
            />
            {data && (
              <Pagination
                page={data.pageNumber}
                pageSize={data.pageSize}
                totalCount={data.totalRecords}
                onPageChange={setPage}
              />
            )}
          </>
        )}
      </div>

      <FormModal
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit article" : "Add article"}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Title</label>
            <input className="input mt-1" {...register("title")} />
            {errors.title && (
              <p className="mt-1 text-xs text-destructive">{errors.title.message}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium">Author</label>
            <input className="input mt-1" {...register("author")} />
          </div>
          <div>
            <label className="text-sm font-medium">Summary</label>
            <textarea className="input mt-1" rows={2} {...register("summary")} />
          </div>
          <div>
            <label className="text-sm font-medium">Content</label>
            <textarea className="input mt-1" rows={5} {...register("content")} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium">Page number</label>
              <input type="number" className="input mt-1" {...register("pageNumber")} />
            </div>
            <div>
              <label className="text-sm font-medium">Keywords</label>
              <input className="input mt-1" {...register("keywords")} />
            </div>
          </div>

          <Controller
            control={control}
            name="coverImageUrl"
            render={({ field }) => (
              <ImageUploadField label="Cover image" value={field.value} onChange={field.onChange} />
            )}
          />
          <Controller
            control={control}
            name="pdfFileUrl"
            render={({ field }) => (
              <PdfUploadField label="PDF file" value={field.value} onChange={field.onChange} />
            )}
          />

          <div className="rounded border border-border p-4">
            <p className="text-sm font-medium">This article belongs to</p>
            <div className="mt-2 flex gap-4">
              <label className="flex items-center gap-2 text-sm">
                <input type="radio" value="magazine" {...register("belongsTo")} />
                Magazine issue
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="radio" value="newspaper" {...register("belongsTo")} />
                Newspaper issue
              </label>
            </div>
            {errors.belongsTo && (
              <p className="mt-1 text-xs text-destructive">{errors.belongsTo.message}</p>
            )}

            <div className="mt-3">
              <label className="text-sm font-medium">
                {belongsTo === "newspaper" ? "Newspaper" : "Magazine"} Issue ID
              </label>
              <input type="number" className="input mt-1" {...register("issueId")} />
              {errors.issueId && (
                <p className="mt-1 text-xs text-destructive">{errors.issueId.message}</p>
              )}
              {belongsTo && issueId ? (
                <IssueConfirmation belongsTo={belongsTo} issueId={Number(issueId)} />
              ) : null}
            </div>
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={createArticle.isPending || updateArticle.isPending}
          >
            {createArticle.isPending || updateArticle.isPending
              ? "Saving…"
              : "Save article"}
          </Button>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(open) => !open && setDeleting(null)}
        title="Delete article"
        description={`This will permanently remove "${deleting?.title}" and is not reversible.`}
        onConfirm={handleDelete}
        isPending={deleteArticle.isPending}
      />
    </div>
  );
}

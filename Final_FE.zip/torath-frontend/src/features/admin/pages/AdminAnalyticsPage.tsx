import { Link } from "react-router-dom";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ArrowLeft, Eye, Star, DollarSign, Download } from "lucide-react";
import { useAnalyticsDashboard } from "../hooks/useAnalyticsDashboard";
import { useNewspaperPaymentAnalytics } from "@/features/newspapers/hooks/useNewspapers";
import { Card } from "@/components/ui/card";
import { ErrorState } from "@/components/shared/ErrorState";
import type { AnalyticsItem } from "../types";

/** Maps the backend's `type` string to a public detail route. */
function itemHref(item: AnalyticsItem): string {
  switch (item.type) {
    case "Book":
      return `/books/${item.id}`;
    case "Magazine":
      return `/magazines/${item.id}`;
    case "Newspaper":
      return `/newspapers/${item.id}`;
    case "Article":
      return `/articles/${item.id}`;
    case "Research Paper":
      return `/research-papers/${item.id}`;
    default:
      return "#";
  }
}

const chartTooltipStyle = {
  background: "hsl(var(--surface))",
  border: "1px solid hsl(var(--border))",
  borderRadius: 4,
  fontSize: 12,
};

function truncate(t: string) {
  return t.length > 20 ? `${t.slice(0, 20)}…` : t;
}

/** GET /api/admin/analytics — computed server-side in SQL, admin-only. */
export function AdminAnalyticsPage() {
  const { data, isLoading, isError, refetch } = useAnalyticsDashboard();
  const { data: paymentData } = useNewspaperPaymentAnalytics();

  return (
    <div>
      <Link
        to="/admin"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Back to Dashboard
      </Link>

      <h1 className="mt-4 font-display text-3xl">Analytics</h1>

      {isLoading && <p className="mt-8 text-sm text-muted-foreground">Loading…</p>}
      {isError && (
        <div className="mt-8">
          <ErrorState onRetry={() => refetch()} />
        </div>
      )}

      {data && (
        <>
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Card className="p-5">
              <Eye className="h-5 w-5 text-accent" />
              <p className="mt-3 font-display text-3xl">
                {data.totalViews.toLocaleString()}
              </p>
              <p className="text-sm text-muted-foreground">Total views, catalog-wide</p>
            </Card>
            <Card className="p-5">
              <p className="font-display text-3xl">{data.totalItems.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">Total items in the catalog</p>
            </Card>
            <Card className="p-5">
              <Star className="h-5 w-5 text-accent" />
              <p className="mt-3 font-display text-3xl">{data.topRated.length}</p>
              <p className="text-sm text-muted-foreground">Rated items shown below</p>
            </Card>
          </div>

          {paymentData && (
            <div className="mt-6">
              <h2 className="font-display text-xl">Newspaper payments</h2>
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Card className="p-5">
                  <Download className="h-5 w-5 text-accent" />
                  <p className="mt-3 font-display text-3xl">
                    {paymentData.totalDownloads.toLocaleString()}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Completed purchases (paid downloads)
                  </p>
                </Card>
                <Card className="p-5">
                  <DollarSign className="h-5 w-5 text-accent" />
                  <p className="mt-3 font-display text-3xl">
                    ${paymentData.totalRevenue.toFixed(2)}
                  </p>
                  <p className="text-sm text-muted-foreground">Total revenue</p>
                </Card>
              </div>
            </div>
          )}

          <div className="mt-8 grid gap-8 lg:grid-cols-2">
            <div>
              <h2 className="font-display text-xl">Most viewed</h2>
              <div className="mt-4 h-80 rounded border border-border p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.topViewed} layout="vertical" margin={{ left: 12 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" fontSize={12} />
                    <YAxis
                      type="category"
                      dataKey="title"
                      width={140}
                      fontSize={11}
                      tickFormatter={truncate}
                    />
                    <Tooltip contentStyle={chartTooltipStyle} />
                    <Bar dataKey="viewCount" fill="hsl(var(--accent))" radius={[0, 3, 3, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div>
              <h2 className="font-display text-xl">Highest rated</h2>
              <div className="mt-4 h-80 rounded border border-border p-4">
                {data.topRated.length === 0 ? (
                  <p className="flex h-full items-center justify-center text-sm text-muted-foreground">
                    No ratings submitted yet.
                  </p>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data.topRated} layout="vertical" margin={{ left: 12 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" domain={[0, 5]} fontSize={12} />
                      <YAxis
                        type="category"
                        dataKey="title"
                        width={140}
                        fontSize={11}
                        tickFormatter={truncate}
                      />
                      <Tooltip contentStyle={chartTooltipStyle} />
                      <Bar dataKey="rating" fill="hsl(var(--info))" radius={[0, 3, 3, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h2 className="font-display text-xl">Most viewed — details</h2>
            <ul className="mt-3 divide-y divide-border rounded border border-border">
              {data.topViewed.map((item) => (
                <li
                  key={`${item.type}-${item.id}`}
                  className="flex items-center justify-between px-4 py-2 text-sm"
                >
                  <Link to={itemHref(item)} className="text-info hover:underline">
                    {item.title}
                    <span className="ml-2 text-xs text-muted-foreground">{item.type}</span>
                  </Link>
                  <span className="text-muted-foreground">
                    {item.viewCount.toLocaleString()} views · {item.rating.toFixed(1)}★
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </div>
  );
}

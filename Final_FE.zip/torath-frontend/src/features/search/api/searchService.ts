import { apiClient } from "@/lib/api/client";
import type { SearchParams, SearchResponse } from "../types";

export const searchService = {
  search: async (params: SearchParams): Promise<SearchResponse> => {
    const { data } = await apiClient.get<SearchResponse>("/api/Search", {
      params: {
        Query: params.query,
        PageNumber: params.pageNumber,
        PageSize: params.pageSize,
        ContentType: params.contentType,
        CategoryId: params.categoryId,
        Language: params.language,
        PublicationDateFrom: params.publicationDateFrom,
        PublicationDateTo: params.publicationDateTo,
        SortBy: params.sortBy,
        SortDescending: params.sortDescending,
      },
    });
    return data;
  },
};

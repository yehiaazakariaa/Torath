/** Matches SearchRequestDto query params exactly. */
export type SearchParams = {
  query?: string;
  pageNumber?: number;
  pageSize?: number;
  contentType?: string;
  categoryId?: number;
  language?: string;
  publicationDateFrom?: string;
  publicationDateTo?: string;
  sortBy?: string;
  sortDescending?: boolean;
};

/**
 * Confirmed against ElasticSearchService.SearchAsync's anonymous result
 * projection — this is NOT the standard PaginatedResponse envelope used
 * by every other list endpoint; Search has its own shape.
 *
 * `databaseId` was added to the SearchDocument model on the backend, but
 * as of the last repo check it is NOT yet selected into this projection
 * (the `Results = searchResponse.Hits.Select(hit => new {...})` block
 * omits it) — so it may or may not be present depending on whether
 * that's been patched since. `resolveResultId` below prefers it when
 * present and falls back to parsing the "{ContentType}_{id}" string
 * otherwise, so the frontend picks up the real fix automatically once
 * the backend adds `DatabaseId = hit.Source?.DatabaseId` to that block.
 */
export type SearchResult = {
  contentType: string;
  id: string;
  databaseId?: number;
  title: string;
  description: string;
  categoryId: number | null;
  language: string;
  publicationDate: string;
  relevanceScore: number | null;
  highlights: Record<string, string[]> | null;
};

export type SearchResponse = {
  totalResults: number;
  pageNumber: number;
  pageSize: number;
  results: SearchResult[];
};

/** Prefers the real numeric databaseId; falls back to parsing it out of the composite id string. */
export function resolveResultId(result: SearchResult): number | null {
  if (typeof result.databaseId === "number" && Number.isFinite(result.databaseId)) {
    return result.databaseId;
  }
  const parts = result.id.split("_");
  const last = parts[parts.length - 1];
  const parsed = Number(last);
  return Number.isFinite(parsed) ? parsed : null;
}

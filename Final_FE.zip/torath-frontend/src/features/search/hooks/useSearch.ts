import { useQuery } from "@tanstack/react-query";
import { searchService } from "../api/searchService";
import type { SearchParams } from "../types";

export const searchKeys = {
  all: ["search"] as const,
  query: (params: SearchParams) => [...searchKeys.all, params] as const,
};

export function useSearch(params: SearchParams) {
  return useQuery({
    queryKey: searchKeys.query(params),
    queryFn: () => searchService.search(params),
    enabled: Boolean(params.query && params.query.trim().length > 0),
    staleTime: 30_000,
  });
}

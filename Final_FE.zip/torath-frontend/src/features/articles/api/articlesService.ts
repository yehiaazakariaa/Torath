import { apiClient } from "@/lib/api/client";
import type { PaginatedResponse } from "@/types/common";
import type { Article, ArticlesListParams, ArticleWriteDto } from "../types";

export const articlesService = {
  getAll: async (
    params: ArticlesListParams
  ): Promise<PaginatedResponse<Article>> => {
    const { data } = await apiClient.get<PaginatedResponse<Article>>(
      "/api/Articles",
      { params }
    );
    return data;
  },
  getById: async (id: number): Promise<Article> => {
    const { data } = await apiClient.get<Article>(`/api/Articles/${id}`);
    return data;
  },
  create: async (dto: ArticleWriteDto): Promise<Article> => {
    const { data } = await apiClient.post<Article>("/api/Articles", dto);
    return data;
  },
  update: async (id: number, dto: ArticleWriteDto): Promise<void> => {
    await apiClient.put(`/api/Articles/${id}`, dto);
  },
  remove: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/Articles/${id}`);
  },

  incrementView: async (id: number): Promise<void> => {
    await apiClient.post(`/api/Articles/${id}/view`);
  },

  rate: async (id: number, rating: number): Promise<void> => {
    await apiClient.post(`/api/Articles/${id}/rate`, rating);
  },
};

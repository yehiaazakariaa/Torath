/** Matches ArticleWriteDto exactly (confirmed 2026-08-06). Now accepts coverImageUrl/pdfFileUrl. */
export type ArticleWriteDto = {
  title?: string | null;
  summary?: string | null;
  content?: string | null;
  author?: string | null;
  pageNumber: number;
  keywords?: string | null;
  coverImageUrl?: string | null;
  pdfFileUrl?: string | null;
  magazineIssueId?: number | null;
  newspaperIssueId?: number | null;
};

/**
 * Confirmed against DTOs/ArticleDtos.cs + ArticleService (2026-08-06) —
 * this one IS fully mapped, no gaps: coverImageUrl/pdfFileUrl/rating/
 * viewCount all round-trip correctly on both read and write.
 */
export type Article = ArticleWriteDto & {
  id: number;
  rating: number;
  viewCount: number;
};

export type ArticlesListParams = {
  page?: number;
  pageSize?: number;
  author?: string;
};

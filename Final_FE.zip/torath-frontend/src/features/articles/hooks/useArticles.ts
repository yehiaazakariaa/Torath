import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { articlesService } from "../api/articlesService";
import type { Article, ArticlesListParams, ArticleWriteDto } from "../types";
import type { PaginatedResponse } from "@/types/common";

export const articlesKeys = {
  all: ["articles"] as const,
  lists: () => [...articlesKeys.all, "list"] as const,
  list: (params: ArticlesListParams) =>
    [...articlesKeys.lists(), params] as const,
  details: () => [...articlesKeys.all, "detail"] as const,
  detail: (id: number) => [...articlesKeys.details(), id] as const,
};

export function useArticles(params: ArticlesListParams) {
  return useQuery({
    queryKey: articlesKeys.list(params),
    queryFn: () => articlesService.getAll(params),
    staleTime: 60_000,
  });
}

export function useArticle(id: number) {
  return useQuery({
    queryKey: articlesKeys.detail(id),
    queryFn: () => articlesService.getById(id),
    enabled: Number.isFinite(id),
  });
}

export function useIncrementArticleView(id: number) {
  return useMutation({
    mutationFn: () => articlesService.incrementView(id),
  });
}

export function useRateArticle(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (rating: number) => articlesService.rate(id, rating),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: articlesKeys.detail(id) });
      queryClient.invalidateQueries({ queryKey: articlesKeys.lists() });
    },
  });
}

export function useCreateArticle() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: ArticleWriteDto) => articlesService.create(dto),
    onSuccess: (created) => {
      queryClient.setQueriesData<PaginatedResponse<Article>>(
        { queryKey: articlesKeys.lists() },
        (old) =>
          old
            ? { ...old, data: [created, ...old.data], totalRecords: old.totalRecords + 1 }
            : old
      );
      queryClient.invalidateQueries({ queryKey: articlesKeys.lists() });
    },
  });
}

export function useUpdateArticle(id: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dto: ArticleWriteDto) => articlesService.update(id, dto),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: articlesKeys.lists() });
      queryClient.invalidateQueries({ queryKey: articlesKeys.detail(id) });
    },
  });
}

export function useDeleteArticle() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => articlesService.remove(id),
    onSuccess: (_data, id) => {
      queryClient.setQueriesData<PaginatedResponse<Article>>(
        { queryKey: articlesKeys.lists() },
        (old) =>
          old
            ? {
                ...old,
                data: old.data.filter((a) => a.id !== id),
                totalRecords: Math.max(0, old.totalRecords - 1),
              }
            : old
      );
      queryClient.invalidateQueries({ queryKey: articlesKeys.lists() });
    },
  });
}

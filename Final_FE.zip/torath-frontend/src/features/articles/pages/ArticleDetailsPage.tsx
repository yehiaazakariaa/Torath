import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { toast } from "sonner";
import { useArticle, useIncrementArticleView, useRateArticle } from "../hooks/useArticles";
import { AccessionTag } from "@/components/shared/AccessionTag";
import { CoverImage } from "@/components/shared/CoverImage";
import { PdfViewerLink } from "@/components/shared/PdfViewerLink";
import { ContentTypeBadge } from "@/components/shared/ContentTypeBadge";
import { ErrorState } from "@/components/shared/ErrorState";
import { RatingBadge } from "@/components/shared/RatingBadge";
import { RatingInput } from "@/components/shared/RatingInput";
import { Skeleton } from "@/components/shared/Skeletons";
import { FadeIn } from "@/components/motion/FadeIn";

export function ArticleDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const articleId = Number(id);
  const { data: article, isLoading, isError, error, refetch } = useArticle(articleId);
  const incrementView = useIncrementArticleView(articleId);
  const rateArticle = useRateArticle(articleId);

  useEffect(() => {
    if (Number.isFinite(articleId)) {
      incrementView.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [articleId]);

  if (isLoading) {
    return (
      <div className="mx-auto grid max-w-4xl grid-cols-1 gap-8 px-4 py-10 md:grid-cols-[220px_1fr]">
        <Skeleton className="aspect-[4/5] w-full" />
        <div className="space-y-3">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-40 w-full" />
        </div>
      </div>
    );
  }

  if (isError || !article) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10">
        <ErrorState
          message={error && "message" in error ? String(error.message) : undefined}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <FadeIn>
      <div className="mx-auto grid max-w-4xl grid-cols-1 gap-8 px-4 py-10 md:grid-cols-[220px_1fr]">
        <CoverImage src={article.coverImageUrl} alt={article.title ?? "Article"} ratio="portrait" />

        <div>
          <div className="flex items-center gap-2">
            <ContentTypeBadge contentType="Article" />
            <AccessionTag contentType="Article" id={article.id} />
          </div>
          <h1 className="mt-3 font-display text-4xl">{article.title}</h1>
          {article.author && (
            <p className="mt-1 text-muted-foreground">By {article.author}</p>
          )}
          <RatingBadge rating={article.rating} viewCount={article.viewCount} className="mt-3" />
          <div className="mt-2">
            <RatingInput
              isSubmitting={rateArticle.isPending}
              onRate={(rating) =>
                rateArticle.mutate(rating, {
                  onSuccess: () => toast.success("Thanks for rating!"),
                  onError: () => toast.error("Couldn't submit your rating"),
                })
              }
            />
          </div>

          {article.summary && (
            <p className="mt-6 text-sm leading-relaxed text-muted-foreground">
              {article.summary}
            </p>
          )}
          {article.content && (
            <div className="prose prose-sm mt-6 max-w-none whitespace-pre-line leading-relaxed">
              {article.content}
            </div>
          )}
          {article.keywords && (
            <p className="mt-6 text-xs uppercase tracking-wide text-muted-foreground">
              Keywords: {article.keywords}
            </p>
          )}

          <div className="mt-6">
            <PdfViewerLink url={article.pdfFileUrl} />
          </div>
        </div>
      </div>
    </FadeIn>
  );
}

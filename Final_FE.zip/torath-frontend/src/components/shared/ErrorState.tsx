import { ScrollText } from "lucide-react";
import { Button } from "@/components/ui/button";

type ErrorStateProps = {
  message?: string;
  onRetry?: () => void;
};

/** Errors state what happened plainly, no apology, no exclamation points. See design system §Copy Voice. */
export function ErrorState({ message, onRetry }: ErrorStateProps) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded border border-border bg-surface py-16 text-center">
      <ScrollText className="h-8 w-8 text-destructive/60" aria-hidden />
      <p className="font-display text-xl">Couldn't load this content</p>
      <p className="max-w-sm text-sm text-muted-foreground">
        {message ?? "It may have been removed, or the connection was lost."}
      </p>
      {onRetry && (
        <Button variant="secondary" size="sm" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}

import { useState } from "react";
import { Star } from "lucide-react";
import { useAuthStore } from "@/features/auth/store";
import { cn } from "@/lib/utils/cn";

type RatingInputProps = {
  onRate: (rating: number) => void;
  isSubmitting?: boolean;
};

/**
 * Whole-star click input (1–5), sent to the backend as a raw double per
 * the `POST /{entity}/{id}/rate` contract. Only rendered for logged-in
 * users — the endpoint requires User/Admin auth.
 *
 * Keeps its own `selected` state so the stars the user clicked stay
 * filled immediately after submitting, independent of the aggregate
 * `rating` shown by RatingBadge (which reflects the average across all
 * users and updates separately once the cache invalidates). This is
 * "the rating I just gave", not "the catalog's average rating".
 */
export function RatingInput({ onRate, isSubmitting }: RatingInputProps) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const [hovered, setHovered] = useState<number | null>(null);
  const [selected, setSelected] = useState<number | null>(null);

  if (!isAuthenticated) return null;

  const displayValue = hovered ?? selected ?? 0;

  return (
    <div className="flex items-center gap-2">
      <div className="flex" onMouseLeave={() => setHovered(null)}>
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            type="button"
            disabled={isSubmitting}
            onClick={() => {
              setSelected(value);
              onRate(value);
            }}
            onMouseEnter={() => setHovered(value)}
            className="p-0.5 disabled:opacity-50"
            aria-label={`Rate ${value} star${value > 1 ? "s" : ""}`}
          >
            <Star
              className={cn(
                "h-5 w-5 transition-colors",
                value <= displayValue
                  ? "fill-accent text-accent"
                  : "text-muted-foreground"
              )}
            />
          </button>
        ))}
      </div>
      <span className="text-xs text-muted-foreground">
        {selected ? `You rated this ${selected}` : "Rate this"}
      </span>
    </div>
  );
}

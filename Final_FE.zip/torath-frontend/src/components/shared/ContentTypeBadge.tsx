import { cn } from "@/lib/utils/cn";
import type { ContentType } from "@/types/common";

const LABELS: Record<ContentType, string> = {
  Book: "Book",
  Magazine: "Magazine",
  MagazineIssue: "Magazine Issue",
  Newspaper: "Newspaper",
  NewspaperIssue: "Newspaper Issue",
  Article: "Article",
  ResearchPaper: "Research Paper",
};

export function ContentTypeBadge({
  contentType,
  className,
}: {
  contentType: ContentType;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-sm bg-info/10 px-2 py-0.5 text-xs font-medium text-info",
        className
      )}
    >
      {LABELS[contentType]}
    </span>
  );
}

type PagePlaceholderProps = {
  title: string;
  phase: string;
};

/**
 * Marks routes that are wired (layout, guards, data hooks where relevant)
 * but whose full page content is scheduled for a later implementation
 * phase, per the project's phased build plan.
 */
export function PagePlaceholder({ title, phase }: PagePlaceholderProps) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-24 text-center">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">
        {phase}
      </p>
      <h1 className="mt-2 font-display text-3xl">{title}</h1>
      <p className="mt-3 text-sm text-muted-foreground">
        Route, layout, and guards are wired. Full page content lands in {phase}.
      </p>
    </div>
  );
}

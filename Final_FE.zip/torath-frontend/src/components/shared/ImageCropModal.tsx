import { useRef, useState } from "react";
import ReactCrop, { centerCrop, makeAspectCrop, type Crop } from "react-image-crop";
import "react-image-crop/dist/ReactCrop.css";
import * as Dialog from "@radix-ui/react-dialog";
import { Button } from "@/components/ui/button";

type ImageCropModalProps = {
  open: boolean;
  imageSrc: string;
  /** width / height, e.g. 4/5 for portrait covers, 16/10 for wide covers. */
  aspect: number;
  onCancel: () => void;
  onConfirm: (blob: Blob) => void;
};

function centeredCrop(width: number, height: number, aspect: number): Crop {
  return centerCrop(
    makeAspectCrop({ unit: "px", width: width * 0.9 }, aspect, width, height),
    width,
    height
  );
}

/** Extracts the cropped region of an <img> into a JPEG Blob via canvas. */
async function cropToBlob(image: HTMLImageElement, crop: Crop): Promise<Blob> {
  const scaleX = image.naturalWidth / image.width;
  const scaleY = image.naturalHeight / image.height;
  const canvas = document.createElement("canvas");
  canvas.width = crop.width * scaleX;
  canvas.height = crop.height * scaleY;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas context unavailable");

  ctx.drawImage(
    image,
    crop.x * scaleX,
    crop.y * scaleY,
    crop.width * scaleX,
    crop.height * scaleY,
    0,
    0,
    canvas.width,
    canvas.height
  );

  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Crop failed"))),
      "image/jpeg",
      0.9
    );
  });
}

/**
 * Lets the admin frame exactly which part of an uploaded photo becomes
 * the cover, before it's sent to /api/Files/upload-image. Crop happens
 * entirely client-side (canvas) — only the final cropped JPEG is
 * uploaded, not the original.
 */
export function ImageCropModal({
  open,
  imageSrc,
  aspect,
  onCancel,
  onConfirm,
}: ImageCropModalProps) {
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleConfirm = async () => {
    if (!imgRef.current || !crop || crop.width === 0) return;
    setIsProcessing(true);
    try {
      const blob = await cropToBlob(imgRef.current, crop);
      onConfirm(blob);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog.Root open={open} onOpenChange={(o) => !o && onCancel()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50" />
        <Dialog.Content className="fixed left-1/2 top-1/2 w-full max-w-lg -translate-x-1/2 -translate-y-1/2 rounded bg-surface p-6 shadow-lg">
          <Dialog.Title className="font-display text-lg">
            Frame the cover image
          </Dialog.Title>
          <Dialog.Description className="mt-1 text-sm text-muted-foreground">
            Drag to select exactly what should appear on the cover.
          </Dialog.Description>

          <div className="mt-4 flex max-h-[60vh] justify-center overflow-auto rounded bg-black/5">
            <ReactCrop
              crop={crop}
              onChange={(pixelCrop) => setCrop(pixelCrop)}
              aspect={aspect}
              keepSelection
            >
              {/* eslint-disable-next-line jsx-a11y/alt-text */}
              <img
                ref={imgRef}
                src={imageSrc}
                onLoad={(e) => {
                  const { width, height } = e.currentTarget;
                  setCrop(centeredCrop(width, height, aspect));
                }}
                className="max-h-[60vh]"
              />
            </ReactCrop>
          </div>

          <div className="mt-6 flex justify-end gap-2">
            <Button variant="secondary" size="sm" onClick={onCancel}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleConfirm} disabled={isProcessing}>
              {isProcessing ? "Processing…" : "Use this crop"}
            </Button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

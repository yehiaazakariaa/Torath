import type { ReactNode } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export type AdminColumn<T> = {
  header: string;
  cell: (row: T) => ReactNode;
};

type AdminTableProps<T extends { id: number }> = {
  rows: T[];
  columns: AdminColumn<T>[];
  onEdit: (row: T) => void;
  onDelete: (row: T) => void;
};

/**
 * Shared table shell for every admin list page — columns are config-driven
 * per entity (Phase 1 §4), so adding a new managed entity means defining
 * a column list, not a new table component.
 */
export function AdminTable<T extends { id: number }>({
  rows,
  columns,
  onEdit,
  onDelete,
}: AdminTableProps<T>) {
  return (
    <div className="overflow-x-auto rounded border border-border">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border bg-muted/50 text-left">
            {columns.map((col) => (
              <th key={col.header} className="px-4 py-3 font-medium">
                {col.header}
              </th>
            ))}
            <th className="px-4 py-3 text-right font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-b border-border last:border-0 hover:bg-muted/30">
              {columns.map((col) => (
                <td key={col.header} className="px-4 py-3">
                  {col.cell(row)}
                </td>
              ))}
              <td className="px-4 py-3 text-right">
                <div className="flex justify-end gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onEdit(row)}
                    aria-label="Edit"
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDelete(row)}
                    aria-label="Delete"
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

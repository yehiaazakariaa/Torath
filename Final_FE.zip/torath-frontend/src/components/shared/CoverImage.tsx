import { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { API_BASE_URL } from "@/lib/api/client";

type CoverImageProps = {
  src?: string | null;
  alt: string;
  /** Books read tall (4:5); issues/newspapers read wide (16:10). */
  ratio?: "portrait" | "wide";
  className?: string;
};

/**
 * Renders the cover if the entity has one. If not (Magazine, MagazineIssue,
 * Newspaper*, NewspaperIssue, Article all lack a cover field in the current
 * backend contract), OR if the image fails to load (e.g. a stale/broken
 * upload URL), falls back to a generated brass linework pattern on stone —
 * never a broken-image icon or raw alt text spilling into the layout.
 *
 * Upload URLs come back from the backend as relative paths
 * ("/uploads/images/x.jpg") — these must be resolved against the API's
 * origin, not the frontend's, or the browser 404s against localhost:5173.
 */
export function CoverImage({
  src,
  alt,
  ratio = "portrait",
  className,
}: CoverImageProps) {
  const [failed, setFailed] = useState(false);
  const aspectClass = ratio === "portrait" ? "aspect-[4/5]" : "aspect-[16/10]";
  const resolvedSrc = src && (src.startsWith("http") ? src : `${API_BASE_URL}${src}`);

  if (!resolvedSrc || failed) {
    return (
      <div
        className={cn(
          "bg-grain flex w-full items-center justify-center overflow-hidden rounded bg-muted",
          aspectClass,
          className
        )}
        role="img"
        aria-label={alt}
      >
        <svg
          viewBox="0 0 100 100"
          className="h-1/3 w-1/3 text-accent/40"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
        >
          <rect x="20" y="15" width="60" height="70" rx="2" />
          <line x1="30" y1="30" x2="70" y2="30" />
          <line x1="30" y1="42" x2="70" y2="42" />
          <line x1="30" y1="54" x2="55" y2="54" />
        </svg>
      </div>
    );
  }

  return (
    <img
      src={resolvedSrc}
      alt={alt}
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn(
        "w-full rounded object-cover transition-transform duration-300 group-hover:scale-105",
        aspectClass,
        className
      )}
    />
  );
}

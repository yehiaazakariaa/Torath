import { motion, useReducedMotion } from "framer-motion";

type NewsTickerProps = {
  items: string[];
};

/**
 * Horizontal scrolling marquee highlighting latest additions. Duplicates
 * the item list once so the CSS/Framer loop has no visible seam, and
 * pauses entirely under prefers-reduced-motion (a continuously moving
 * marquee is exactly the kind of motion that spec exists to suppress).
 */
export function NewsTicker({ items }: NewsTickerProps) {
  const reduceMotion = useReducedMotion();
  const loopItems = [...items, ...items];

  if (items.length === 0) return null;

  return (
    <div className="overflow-hidden border-y border-border bg-accent/10 py-2.5">
      <div className="flex items-center">
        <span className="z-10 flex-shrink-0 bg-accent px-3 py-1 text-xs font-medium uppercase tracking-wide text-accent-foreground">
          Latest
        </span>

        {reduceMotion ? (
          <div className="flex gap-8 overflow-x-auto px-4 text-sm">
            {items.map((item, i) => (
              <span key={i} className="whitespace-nowrap">
                {item}
              </span>
            ))}
          </div>
        ) : (
          <motion.div
            className="flex gap-8 whitespace-nowrap px-4 text-sm"
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 30, ease: "linear", repeat: Infinity }}
          >
            {loopItems.map((item, i) => (
              <span key={i}>{item}</span>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
}

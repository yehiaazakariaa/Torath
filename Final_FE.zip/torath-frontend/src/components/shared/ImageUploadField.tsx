import { useState } from "react";
import { Image as ImageIcon, X } from "lucide-react";
import { toast } from "sonner";
import { filesService } from "@/lib/api/filesService";
import { toApiError } from "@/lib/api/errors";
import { ImageCropModal } from "./ImageCropModal";

type ImageUploadFieldProps = {
  label: string;
  value: string | null | undefined;
  onChange: (url: string | null) => void;
  /** width / height of the crop frame — matches the CoverImage ratio it will be shown at. */
  aspect?: number;
};

export function ImageUploadField({
  label,
  value,
  onChange,
  aspect = 4 / 5,
}: ImageUploadFieldProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [pendingImageSrc, setPendingImageSrc] = useState<string | null>(null);

  const handleFileSelect = (file: File | undefined) => {
    if (!file) return;
    // Don't upload yet — open the crop tool first so the admin can frame
    // the cover before anything is sent to the server.
    setPendingImageSrc(URL.createObjectURL(file));
  };

  const handleCropConfirm = async (blob: Blob) => {
    const src = pendingImageSrc;
    setPendingImageSrc(null);
    if (src) URL.revokeObjectURL(src);

    setIsUploading(true);
    try {
      const croppedFile = new File([blob], "cover.jpg", { type: "image/jpeg" });
      const url = await filesService.uploadImage(croppedFile);
      onChange(url);
    } catch (error) {
      toast.error(toApiError(error).message);
    } finally {
      setIsUploading(false);
    }
  };

  const handleCropCancel = () => {
    if (pendingImageSrc) URL.revokeObjectURL(pendingImageSrc);
    setPendingImageSrc(null);
  };

  return (
    <div>
      <label className="text-sm font-medium">{label}</label>
      <div className="mt-1 flex items-center gap-3">
        {value ? (
          <div className="relative">
            <img src={value} alt="" className="h-20 w-20 rounded object-cover" />
            <button
              type="button"
              onClick={() => onChange(null)}
              className="absolute -right-2 -top-2 rounded-full bg-destructive p-1 text-destructive-foreground"
              aria-label="Remove image"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        ) : (
          <div className="flex h-20 w-20 items-center justify-center rounded border border-dashed border-border">
            <ImageIcon className="h-6 w-6 text-muted-foreground" />
          </div>
        )}
        <label className="cursor-pointer rounded border border-border px-3 py-1.5 text-sm hover:bg-muted">
          {isUploading ? "Uploading…" : value ? "Replace" : "Upload"}
          <input
            type="file"
            accept="image/*"
            className="hidden"
            disabled={isUploading}
            onChange={(e) => {
              handleFileSelect(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </label>
      </div>

      {pendingImageSrc && (
        <ImageCropModal
          open
          imageSrc={pendingImageSrc}
          aspect={aspect}
          onCancel={handleCropCancel}
          onConfirm={handleCropConfirm}
        />
      )}
    </div>
  );
}

import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ReactNode } from "react";

type CarouselProps = {
  children: ReactNode[];
  /** Approximate width of each item, in px, used to scroll one "page" at a time. */
  itemWidth?: number;
};

/**
 * Horizontal scroll-snap carousel — native scroll + CSS snap for buttery
 * touch/trackpad dragging, with button controls for keyboard/mouse users.
 * Simpler and more robust than a JS drag implementation for a card rail.
 */
export function Carousel({ children, itemWidth = 260 }: CarouselProps) {
  const trackRef = useRef<HTMLDivElement>(null);

  const scrollByPage = (direction: 1 | -1) => {
    trackRef.current?.scrollBy({
      left: direction * itemWidth * 2,
      behavior: "smooth",
    });
  };

  return (
    <div className="group/carousel relative">
      <div
        ref={trackRef}
        className="flex snap-x snap-mandatory items-stretch gap-6 overflow-x-auto scroll-smooth pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {children.map((child, i) => (
          <div key={i} className="snap-start" style={{ minWidth: itemWidth }}>
            {child}
          </div>
        ))}
      </div>

      <Button
        variant="secondary"
        size="icon"
        onClick={() => scrollByPage(-1)}
        aria-label="Scroll left"
        className="absolute -left-4 top-1/3 hidden -translate-y-1/2 opacity-0 shadow-md transition-opacity group-hover/carousel:opacity-100 md:flex"
      >
        <ChevronLeft className="h-4 w-4" />
      </Button>
      <Button
        variant="secondary"
        size="icon"
        onClick={() => scrollByPage(1)}
        aria-label="Scroll right"
        className="absolute -right-4 top-1/3 hidden -translate-y-1/2 opacity-0 shadow-md transition-opacity group-hover/carousel:opacity-100 md:flex"
      >
        <ChevronRight className="h-4 w-4" />
      </Button>
    </div>
  );
}

import { Link } from "react-router-dom";
import { memo } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { AccessionTag } from "./AccessionTag";
import { CoverImage } from "./CoverImage";
import type { ContentType } from "@/types/common";

type ContentCardProps = {
  href: string;
  title: string;
  subtitle?: string | null;
  contentType: ContentType;
  id: number;
  coverUrl?: string | null;
  ratio?: "portrait" | "wide";
};

/**
 * The card used everywhere content is listed — Home rails, Browse grids,
 * carousels. Combines the signature AccessionTag, the CoverImage fallback
 * pattern, and the hover lift + brass glow from the design system.
 *
 * Memoized: grids render up to a few dozen of these per page, and parent
 * re-renders (sort changes, filter typing, pagination) shouldn't force
 * every unaffected card to re-run its render + Framer Motion setup.
 */
export const ContentCard = memo(function ContentCard({
  href,
  title,
  subtitle,
  contentType,
  id,
  coverUrl,
  ratio = "portrait",
}: ContentCardProps) {
  const reduceMotion = useReducedMotion();

  return (
    <motion.div
      whileHover={reduceMotion ? undefined : { y: -4 }}
      transition={{ duration: 0.15, ease: "easeOut" }}
      className="group h-full"
    >
      <Link
        to={href}
        className="flex h-full flex-col rounded border border-border bg-surface p-3 shadow-[0_0_0_0_transparent] transition-shadow duration-150 hover:shadow-[0_8px_24px_-8px_hsl(var(--accent)/0.35)]"
      >
        <div className="relative overflow-hidden rounded">
          <CoverImage src={coverUrl} alt={title} ratio={ratio} />
          <AccessionTag
            contentType={contentType}
            id={id}
            className="absolute right-2 top-2 bg-surface/90"
          />
        </div>
        <h3 className="mt-3 line-clamp-2 min-h-[2.5rem] font-display text-base leading-snug">
          {title}
        </h3>
        <p className="mt-0.5 line-clamp-1 min-h-[1.125rem] text-xs text-muted-foreground">
          {subtitle ?? ""}
        </p>
      </Link>
    </motion.div>
  );
});

import type { ReactNode } from "react";
import { cn } from "@/lib/utils/cn";

type BackgroundSectionProps = {
  image: string;
  /**
   * "dark" = dark scrim, use light text (for photos with bright/busy
   * midtones — sunsets, gold on black, stone carvings).
   * "light" = light scrim, use dark text (for photos with a lot of
   * open sky/sand where a dark overlay would look heavy).
   */
  overlay?: "dark" | "light" | "none";
  /** Overlay strength — higher = more legible text, less visible photo. */
  intensity?: "subtle" | "medium" | "strong";
  className?: string;
  children: ReactNode;
  /**
   * Set true only for a section that's above the fold on first load (the
   * Home hero, essentially). Renders the image as a real high-priority
   * <img> instead of a CSS background — a background-image is invisible
   * to the browser's preload scanner and only starts fetching once JS
   * has evaluated and applied the inline style, which measurably delays
   * LCP for whatever section is the largest above-the-fold element.
   * Everything else should stay the default (false): those sections are
   * lower in the page, so deprioritizing their image load is correct,
   * not a regression.
   */
  priority?: boolean;
};

const OVERLAY_CLASSES: Record<
  NonNullable<BackgroundSectionProps["overlay"]>,
  Record<NonNullable<BackgroundSectionProps["intensity"]>, string>
> = {
  dark: {
    subtle: "bg-black/30",
    medium: "bg-black/55",
    strong: "bg-black/75",
  },
  light: {
    subtle: "bg-stone-50/40 backdrop-brightness-110",
    medium: "bg-stone-50/65",
    strong: "bg-stone-50/85",
  },
  none: { subtle: "", medium: "", strong: "" },
};

/**
 * Wraps any section in a photo background with a scrim tuned for text
 * legibility — per design brief: dark or bright overlay chosen to match
 * the photo, never bare text over a busy image.
 */
export function BackgroundSection({
  image,
  overlay = "dark",
  intensity = "medium",
  className,
  children,
  priority = false,
}: BackgroundSectionProps) {
  return (
    <div
      className={cn("relative overflow-hidden", !priority && "bg-cover bg-center", className)}
      style={priority ? undefined : { backgroundImage: `url(${image})` }}
    >
      {priority && (
        <img
          src={image}
          alt=""
          fetchPriority="high"
          loading="eager"
          decoding="async"
          className="absolute inset-0 h-full w-full object-cover"
        />
      )}
      <div
        className={cn(
          "absolute inset-0",
          OVERLAY_CLASSES[overlay][intensity]
        )}
        aria-hidden
      />
      <div className={cn("relative", overlay === "dark" && "text-white")}>
        {children}
      </div>
    </div>
  );
}

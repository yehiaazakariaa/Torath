import { BookX } from "lucide-react";
import type { ReactNode } from "react";

type EmptyStateProps = {
  title: string;
  description?: string;
  action?: ReactNode;
};

/** Copy voice: an empty screen is an invitation to act, not a dead end. See design system §Copy Voice. */
export function EmptyState({ title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded border border-dashed border-border py-16 text-center">
      <BookX className="h-8 w-8 text-accent/50" aria-hidden />
      <p className="font-display text-xl">{title}</p>
      {description && (
        <p className="max-w-sm text-sm text-muted-foreground">{description}</p>
      )}
      {action}
    </div>
  );
}

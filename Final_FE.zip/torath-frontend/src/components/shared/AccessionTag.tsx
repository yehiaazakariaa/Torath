import { cn } from "@/lib/utils/cn";
import { CONTENT_TYPE_PREFIX, type ContentType } from "@/types/common";

type AccessionTagProps = {
  contentType: ContentType;
  id: number;
  /** Optional third segment, e.g. an issue's publication year: NP·1904·012 */
  suffix?: string | number;
  className?: string;
};

/**
 * The project's signature UI element (see design system §Signature).
 * Renders a real content-type prefix + real database ID as a small
 * archival-style inventory mark — not decorative, it's the item's
 * actual identity in the catalog.
 */
export function AccessionTag({
  contentType,
  id,
  suffix,
  className,
}: AccessionTagProps) {
  const prefix = CONTENT_TYPE_PREFIX[contentType];
  const paddedId = String(id).padStart(4, "0");
  const label = suffix
    ? `${prefix}·${suffix}·${paddedId}`
    : `${prefix}·${paddedId}`;

  return (
    <span
      className={cn(
        "inline-flex items-center rounded border border-border bg-surface/80 px-1.5 py-0.5 font-sans text-xs uppercase tracking-wide text-muted-foreground",
        className
      )}
      aria-label={`Catalog reference ${label}`}
    >
      {label}
    </span>
  );
}

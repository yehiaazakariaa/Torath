import { FileText } from "lucide-react";
import { API_BASE_URL } from "@/lib/api/client";

type PdfViewerLinkProps = {
  url?: string | null;
};

/** Renders nothing when the entity has no PDF field/value — see design system §PdfViewerLink. */
export function PdfViewerLink({ url }: PdfViewerLinkProps) {
  if (!url) return null;

  const href = url.startsWith("http") ? url : `${API_BASE_URL}${url}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-2 text-sm font-medium text-info hover:underline"
    >
      <FileText className="h-4 w-4" aria-hidden />
      Open PDF
    </a>
  );
}

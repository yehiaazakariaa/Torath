import { Star, Eye } from "lucide-react";
import { cn } from "@/lib/utils/cn";

export function RatingBadge({
  rating,
  viewCount,
  className,
}: {
  rating: number;
  viewCount: number;
  className?: string;
}) {
  return (
    <div className={cn("flex items-center gap-3 text-xs text-muted-foreground", className)}>
      <span className="flex items-center gap-1">
        <Star className="h-3.5 w-3.5 fill-accent text-accent" />
        {rating.toFixed(1)}
      </span>
      <span className="flex items-center gap-1">
        <Eye className="h-3.5 w-3.5" />
        {viewCount.toLocaleString()}
      </span>
    </div>
  );
}

/**
 * Client-side sort of the CURRENTLY LOADED PAGE only. No list endpoint in
 * the API accepts a sort parameter (confirmed against every Controller),
 * and Rating/ViewCount aren't indexed in Elasticsearch either, so a true
 * "highest rated across the whole catalog" sort isn't possible without a
 * backend change. This is an honest stopgap, labeled as such in the UI.
 */
export type SortOption = "default" | "rating" | "views";

export function SortControl({
  value,
  onChange,
}: {
  value: SortOption;
  onChange: (value: SortOption) => void;
}) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <label className="text-muted-foreground">Sort this page:</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as SortOption)}
        className="rounded border border-border bg-surface px-2 py-1 text-sm"
      >
        <option value="default">Default</option>
        <option value="rating">Highest rated</option>
        <option value="views">Most viewed</option>
      </select>
    </div>
  );
}

export function applySort<T extends { rating: number; viewCount: number }>(
  items: T[],
  sort: SortOption
): T[] {
  if (sort === "default") return items;
  const copy = [...items];
  if (sort === "rating") return copy.sort((a, b) => b.rating - a.rating);
  return copy.sort((a, b) => b.viewCount - a.viewCount);
}

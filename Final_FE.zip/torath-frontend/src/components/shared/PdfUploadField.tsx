import { useState } from "react";
import { FileText, X } from "lucide-react";
import { toast } from "sonner";
import { filesService } from "@/lib/api/filesService";
import { toApiError } from "@/lib/api/errors";

type PdfUploadFieldProps = {
  label: string;
  value: string | null | undefined;
  onChange: (url: string | null) => void;
};

export function PdfUploadField({ label, value, onChange }: PdfUploadFieldProps) {
  const [isUploading, setIsUploading] = useState(false);

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    setIsUploading(true);
    try {
      const url = await filesService.uploadPdf(file);
      onChange(url);
    } catch (error) {
      toast.error(toApiError(error).message);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div>
      <label className="text-sm font-medium">{label}</label>
      <div className="mt-1 flex items-center gap-3">
        {value ? (
          <span className="flex items-center gap-2 rounded border border-border px-3 py-1.5 text-sm">
            <FileText className="h-4 w-4 text-info" />
            PDF attached
            <button
              type="button"
              onClick={() => onChange(null)}
              aria-label="Remove PDF"
            >
              <X className="h-3 w-3 text-destructive" />
            </button>
          </span>
        ) : (
          <label className="cursor-pointer rounded border border-border px-3 py-1.5 text-sm hover:bg-muted">
            {isUploading ? "Uploading…" : "Upload PDF"}
            <input
              type="file"
              accept="application/pdf"
              className="hidden"
              disabled={isUploading}
              onChange={(e) => handleFile(e.target.files?.[0])}
            />
          </label>
        )}
      </div>
    </div>
  );
}

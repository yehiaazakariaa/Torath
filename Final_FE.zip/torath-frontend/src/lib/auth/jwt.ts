import { jwtDecode } from "jwt-decode";

/**
 * ASP.NET Core Identity issues the role claim under the standard
 * Microsoft XML schema URI, not a bare "role" key. Confirmed against
 * the Torath backend — do not change without re-checking a decoded token.
 */
export const ROLE_CLAIM_KEY =
  "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";

/**
 * Backend issues ClaimTypes.NameIdentifier (the user's numeric ID), NOT a
 * "name" claim — confirmed against AuthService.CreateToken in the backend
 * repo. There is no full-name claim in the token at all (FullName isn't
 * included), so the UI cannot display a name from the JWT — only email
 * and this numeric ID are available.
 */
export const USER_ID_CLAIM_KEY =
  "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";

export const EMAIL_CLAIM_KEY =
  "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";

export type TorathJwtClaims = {
  [ROLE_CLAIM_KEY]?: string;
  [USER_ID_CLAIM_KEY]?: string;
  [EMAIL_CLAIM_KEY]?: string;
  sub?: string;
  exp?: number;
  [key: string]: unknown;
};

export type Session = {
  role: string | null;
  userId: string | null;
  email: string | null;
  isAdmin: boolean;
  isExpired: boolean;
};

/**
 * Decodes a JWT and extracts the fields the UI needs. Never throws —
 * a malformed/expired token is treated as "no session" by the caller.
 */
export function decodeSession(token: string): Session | null {
  try {
    const claims = jwtDecode<TorathJwtClaims>(token);
    const role = claims[ROLE_CLAIM_KEY] ?? null;
    const isExpired = claims.exp ? claims.exp * 1000 < Date.now() : false;

    return {
      role,
      userId: claims[USER_ID_CLAIM_KEY] ?? null,
      email: claims[EMAIL_CLAIM_KEY] ?? null,
      isAdmin: role === "Admin",
      isExpired,
    };
  } catch {
    return null;
  }
}

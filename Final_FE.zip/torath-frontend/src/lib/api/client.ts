import axios from "axios";
import { getToken, clearToken } from "@/lib/auth/token";

export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ?? "https://localhost:7231";

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Attach the JWT to every request when present.
apiClient.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/**
 * Dispatched on the window when a request comes back 401 (expired/invalid
 * token) so the auth layer can clear session state and redirect to /login
 * without lib/api importing the auth store directly (would create a
 * circular dependency between lib/api ↔ features/auth).
 */
export const SESSION_EXPIRED_EVENT = "torath:session-expired";

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      clearToken();
      window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT));
    }
    return Promise.reject(error);
  }
);

/** Separate instance for multipart uploads — Content-Type must be left
 * unset so the browser sets the multipart boundary itself. */
export const apiUploadClient = axios.create({
  baseURL: API_BASE_URL,
});

apiUploadClient.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

apiUploadClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      clearToken();
      window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT));
    }
    return Promise.reject(error);
  }
);

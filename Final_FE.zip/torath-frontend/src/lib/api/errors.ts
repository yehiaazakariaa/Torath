import { AxiosError } from "axios";

export type ApiError = {
  status: number | null;
  message: string;
};

/**
 * Normalizes anything Axios can throw into one shape every feature's
 * error UI can rely on, regardless of whether the backend returned a
 * problem-details body, a plain string, or nothing (network failure).
 */
export function toApiError(error: unknown): ApiError {
  if (error instanceof AxiosError) {
    const status = error.response?.status ?? null;
    const data = error.response?.data;

    const message =
      (typeof data === "string" && data) ||
      (typeof data === "object" && data !== null && "message" in data
        ? String((data as { message: unknown }).message)
        : null) ||
      (typeof data === "object" && data !== null && "title" in data
        ? String((data as { title: unknown }).title)
        : null) ||
      error.message ||
      "Something went wrong. Please try again.";

    return { status, message };
  }

  return { status: null, message: "Something went wrong. Please try again." };
}

import { apiUploadClient } from "@/lib/api/client";

type UploadResponse = { url: string };

export const filesService = {
  uploadImage: async (file: File): Promise<string> => {
    const formData = new FormData();
    formData.append("file", file);
    const { data } = await apiUploadClient.post<UploadResponse>(
      "/api/Files/upload-image",
      formData
    );
    return data.url;
  },

  uploadPdf: async (file: File): Promise<string> => {
    const formData = new FormData();
    formData.append("file", file);
    const { data } = await apiUploadClient.post<UploadResponse>(
      "/api/Files/upload-pdf",
      formData
    );
    return data.url;
  },

  deleteFile: async (fileUrl: string): Promise<void> => {
    await apiUploadClient.delete("/api/Files/delete-file", {
      params: { fileUrl },
    });
  },
};
